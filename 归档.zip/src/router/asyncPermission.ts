import { RouteConfig } from 'vue-router'

import Layout from '@/layout/Layout.vue'

const System: RouteConfig[] = [
  // {
  //   path: '/index',
  //   component: Layout,
  //   name: "index",
  //   meta: {
  //     icon: "setting",
  //     title: "资源中心"
  //   },
  //   children: [
  //     {
  //       path: '/dataBank',
  //       name: 'system',
  //       meta: { title: '系统管理' },
  //       component: () => import('@/views/dataBank')
  //     },
  //   ]
  // },
]
export default System