import Vue from 'vue'
import VueRouter, { RawLocation, RouteConfig } from 'vue-router'
import NotFound from '../404.vue'
import asyncRouter from '@/router/asyncPermission'
import Layout from '@/layout/Layout.vue'


Vue.use(VueRouter)

const routes: Array<RouteConfig> = [
  {
    path: '/',
    redirect: '/dataBank',
    component: Layout,
    name: "index",
    meta: {
      icon: "setting",
      title: "资料中心"
    },
    children: [
      {
        path: '/dataBank',
        name: 'system',
        meta: { title: '我的资料' },
        component: () => import('@/views/dataBank/index.vue')
      },
    ]
  },
  ...asyncRouter,
  {
    path: '/login',
    name: 'login',
    meta: { title: '登录' },
    component: () => import('@/views/login/index.vue')
  },
  {
    path: '*', component: NotFound
  }
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to: any, from: any, next: any) => {
  next()
})

export default router
