import axios from './axios'

// 获取资源库右侧资料列表
export function getUserResource(params) {
    return axios.post('/resource/Resource/getUserResource', params)
}

//新建文件夹
export function addFolder(params) {
    return axios.post("/resource/Resource/addFolder", params)
}

//修改文件夹
export function editFilename(params) {
    return axios.post("/resource/Resource/editFolder", params)
}

//修改文件（包括名称和学科）
export function editFile(params) {
    return axios.post("/resource/Resource/userSourceFileManage", params)
}

//删除文件夹
export function deleteFolder(params) {
    return axios.post("/resource/Resource/batchDeleteResource", params)
}

//下载文件
export function downloadFile(params) {
    return axios.post("/resource/Resource/getFileTempUrl", params)
}

//下载图片
export function downloadByUrl(url) {
    return axios.get(url, { responseType: 'blob' })
}

//移动文件、文件夹
export function moveFile(params) {
    return axios.post("/resource/Resource/batchMoveResource", params)
}

//分享文件、文件夹到【校本，共享资源，指定学校校本】
export function shareFile(params) {
    params.action = "shareUserFile"
    return axios.post("/resource/Resource/userSourceFileManage", params)
}

//取消共享
export function unShareFile(params) {
    params.action = "unShareUserFile"
    return axios.post("/resource/Resource/userSourceFileManage", params)
}


//获取共享库的年级学科列表
export function getShareGradeList(params) {
    return axios.get("/tp/public/index.php/resource/v1/SharedLibrary/getBaseConfig", { params })
}

//共享到年级共享库
export function shareFileToGrade(params) {
    return axios.post("/tp/public/index.php/resource/v1/SharedLibrary/toShareResource", params)
}

//保存个人资源到书内
export function savePersonResourceToBook(params) {
    return axios.post("/tp/public/index.php/resource/v1/PersonResource/savePersonResourceToBook", params)
}