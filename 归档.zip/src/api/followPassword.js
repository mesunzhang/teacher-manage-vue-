import axios from './axios'
/**
 * 找回密码接口
 * @class Password
 */

class Password {
    constructor() {}
        /**
         * 校验平板账号
         */
    checkLogonName(data) {
            return axios.post('/tp/public/index.php/user/v1/Login/checkLogonName', data)
        }
        /**
         * 找回密码
         */
    forgetPassword(data) {
            return axios.post('/tp/public/index.php/user/v1/Login/forgetPassword', data)
        }
        //发送短信验证码
    sendSms(data) {
            return axios.post('/tp/public/index.php/user/v1/Login/sendSms', data)
        }
        /**
         * 获取校验验证码
         */
    getValidateImage(data) {
        return axios.post('/tp/public/index.php/user/v1/Login/getValidateImage', data)
    }


}

export default new Password()