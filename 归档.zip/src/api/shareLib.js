import axios from './axios'

// 取消分享
export function unShareFile(params) {
    return axios.post('/tp/public/index.php/resource/v1/SharedLibrary/cancelShare', params)
}

// 年级共享资源列表
export function getShareLibResourceList(params) {
    return axios.post('/tp/public/index.php/resource/v1/SharedLibrary/search', params)
}