import axios from './axios'
import store from '../store/index'

/**
 * 公共接口
 * @class CommonApi
 */

class CommonApi {
    constructor() {}

    /**
     * 登录
     * @param params
     * @returns {Promise<AxiosResponse<T>>}
     */
    login(params) {
        return axios.post('/tp/public/index.php/user/v1/Login/loginIn', params)
    }

    sendSms(params) {
        return axios.post('/tp/public/index.php/user/v1/Login/sendSms', params)
    }

    /**
     * 获取公共枚举
     * @returns {Object} 返回公共枚举
     */
    getCommonEnumerateList() {
        return axios.get('/common/Enum/list')
    }

    /**
     * 获取关系型枚举
     * @param {String} relationType - StageBookTypeSubdivide 学段,学科,年级,教材版本
     * @param {String} relationType - SubjectRelevanceQuestionUserType 学科用户题型
     * @param {String} relationType - SubjectRelevanceQuestionSystemType 学科系统题型
     * @param {String} relationType - QuestionSystemTypeSubjectRelevanceQuestionUserType 系统题型用户题型交集关联
     * @returns {Array} 返回关系枚举
     */
    relation(relationType, params) {
        let result = store.state.commonModule[relationType]
        let query = ''
        if (params) {
            for (let key in params) {
                query += '&' + key + '=' + params[key]
            }
        }
        return result.length ? Promise.resolve({
            code: 200,
            data: result,
            exist: true
        }) : axios.get('/common/Enum/relation?relationType=' + relationType + query)
    }

    /**
     * 获取教师上一次选择的枚举
     * @returns {Object} stage 学段 subject 学科 grade 年级 textBookVersion 教材版本
     */
    getTeacherDefault() {
        return axios.get('/home/paper/getDefault')
    }

    /**
     * 设置教师学段,学科,年级,教材版本枚举
     * @param {Object} params 参数对象
     * @param {Number} [params.stage] 学段
     * @param {Number} [params.subjectId] 学科
     * @param {Number} [params.grade] 年级
     * @param {Number} [params.textBookVersion] 教材版本
     * @returns {Object} 成功消息
     */
    setTeacherDefault(params) {
        return axios.post('/home/Home/setDefaultBookType', params)
    }

    /**
     *查询题目详情
     * @param params
     * @returns {*}
     */
    getQuestionDetail(params) {
        return axios.post('/common/Question/getQuestionList', params)
    }

    /**
     * 获取获取班级列表接口
     */
    getClassList() {
        return axios.post('/resource/Resource/getClassList')
    }

    /**
     * 批量设置公开权限接口
     */
    setAuth(params) {
        return axios.post('/resource/Resource/batchSetResourcePublic', params)
    }

    /**
     * 获取上传文件说明
     */
    getUploadExplain() {
        return axios.post('/resource/Resource/getUploadExplain')
    }

    getWxCode() {
        return axios.get('/tp/public/index.php/user/v1/Login/getWxQrAuthUrl')
    }

    bindPhone(params) {
        return axios.post('/tp/public/index.php/user/v1/UserBase/bindMobile', params)
    }


    //获取当前用户的相关信息
    getUserInfo() {
        return axios.post('/tp/public/index.php/user/v1/UserBase/getUserBaeInfo')
    }

    //查询自建书或者校本书书资源
    getSchoolResourceBooks(params){
        return axios.post('/tp/public/index.php/xhcommon/v1/books/getSchoolResourceBooks',params)
    }

    //查询自建书或者校本书书资源下的所有目录
    getSchoolResourceBooksCatalogs(params){
        return axios.post('/tp/public/index.php/xhcommon/v1/books/getSchoolResourceBooksCatalogs',params)
    }

    //根据书本id和目录id查询所有文件夹集合
    getSchoolFolderByBookIdAndCatalogId(params){
        return axios.post('/tp/public/index.php/schoolresource/v1/BookResource/getSchoolFolderByBookIdAndCatalogId',params)
    }

    //转到书内
    userSourceFileManage(params){
        return axios.post('/resource/Resource/userSourceFileManage',params)
    }
}

export default new CommonApi()