import axios from './axios'
/**
 * 公共接口
 * @class CommonApi
 */

class PowerApi {
    constructor() {}
        /**
         * 获取左侧目录树结构
         * @param params
         * @returns {Promise<AxiosResponse<T>>}
         */
    getFolder() {
            return axios.post('/resource/Resource/getMyFolder')
        }
        // 获取右侧资料列表
    getUserResourceList(params) {
            return axios.post('/resource/Resource/getUserResourceList', params)
        }
        // 获取班级列表接口
    getClassList() {
            return axios.post('/resource/Resource/getClassList')
        }
        // 批量取消公开权限
    batchClose(params) {
            return axios.post('/resource/Resource/batchClose', params)
        }
        //获取操作记录
    unpublicLog(params) {
            return axios.post('/resource/Resource/unpublicLog', params)
        }
        //获取操作记录
    getUnpublicLogDetail(params) {
        return axios.post('/resource/Resource/getUnpublicLogDetail', params)
    }

    // 获取共享库设置
    getConfig(params) {
        return axios.get('/tp/public/index.php/resource/v1/SharedLibrary/getConfig', {
            params
        })
    }

    // 获取基础配置
    getBaseConfig(params) {
            return axios.get('/tp/public/index.php/resource/v1/SharedLibrary/getBaseConfig', {
                params
            })
        }
        // 获取共享库文件夹列表
    getShareFolderList(params) {
        return axios.get('/tp/public/index.php/resource/v1/SharedLibrary/getFolderList', {
            params
        })
    }

    // 搜索学校列表
    getSchoolList(params) {
        return axios.post('/common/school/searchSchool', params)
    }

    //保存共享库配置
    setShareLibConfig(params) {
        return axios.post('/tp/public/index.php/resource/v1/SharedLibrary/setConfig', params)
    }

    //共享资源转存到个人库
    shareToPersonResource(params) {
        return axios.post('/tp/public/index.php/resource/v1/SharedLibrary/toPersonResource', params)
    }

}

export default new PowerApi()