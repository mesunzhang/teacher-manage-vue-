import axios from 'axios'
import message from 'ant-design-vue/lib/message'
import modal from 'ant-design-vue/lib/modal'
import store from '../store/index'
import Vue from 'vue'

const h = new Vue().$createElement

axios.defaults.timeout = 90000
    // axios.defaults.baseURL="http://192.168.5.5:8079"

// 添加请求拦截器
axios.interceptors.request.use((config) => {

    store.commit('setLoading', true)
      
    return config
}, function(error) {
    // 对请求错误做些什么
    return Promise.reject(error)
})

function msgArr(msg) {
    let splitResult = msg.split(/<br.*?>/g)
    return splitResult.map((item) => {
        return h('p', {
            style: {
                'margin-bottom': '0'
            }
        }, item)
    })
}

// 添加响应拦截器
axios.interceptors.response.use((response) => {
    let data = response.data
    let code = parseInt(data.code / 100)
    store.commit('setLoading', false)
    if (code === 4 || code === 5) {
        data.msg && modal.error({
            title: '提示',
            content: h('div', msgArr(data.msg)),
            maskClosable: true,
            okText: '确定'
        })
        return Promise.reject(data)
    } else if (data.code >= 200 && data.code <= 300 || data.code === 302) {
        data.msg && message.success(data.msg)
        return data
    } else {
        data.msg && message.error(data.msg)
        return data
    }
}, (error) => {
    if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        message.error(error.response.status)
        console.log(error.response.data)
        console.log(error.response.status)
        console.log(error.response.headers)
    } else if (error.request) {
        message.error('请求错误')
        console.log(error.request)
    } else {
        message.error('请求超时')
    }
    store.commit('setLoading', false)
        // 对响应错误做点什么
    return Promise.reject(error)
})

export default axios