import Vue from 'vue'
import Component from 'vue-class-component'

@Component
export class BaseMixin extends Vue {
  // @ts-ignore
  // hrefTo(url: string, sysTem: SystemEnum = SystemEnum.setting): void {
  //   location.href = systemOtherConfig[sysTem].domain + url
  // }
}