import { GET, ParamOption, POST, PUT, DELETE } from '@/httpService/axios'



/**
 * 查询教材列表
 * @export
 * @returns
 */
export function getBookList(params?: any, option?: ParamOption){
    return GET('/api/v1/book', arguments)
}

/**
 * 新建教材
 * @export
 * @returns
 */
export function createBook(params?: any, option?: ParamOption){
    return POST('/api/v1/book', arguments)
}

/**
 * 根据教材id查询教材信息
 * @export
 * @returns
 */
export function getBookInfo(params?: any, option?: ParamOption){
    return GET(`/api/v1/book/${params.bookId}`, arguments)
}

/**
 * 修改教材基础信息
 * @export
 * @returns
 */
export function editBook(params?: any, option?: ParamOption){
    return PUT(`/api/v1/book/${params.bookId}`, arguments)
}

/**
 * 删除教材
 * @export
 * @returns
 */
export function deleteBook(params?: any, option?: ParamOption){
    return DELETE(`/api/v1/book/${params.bookId}/user/${params.userId}`, arguments)
}


/**
 * 按教材id查询激活码批次信息
 * @export
 * @returns
 */
export function getActivation(params?: any, option?: ParamOption){
  return GET('/api/v1/activation', arguments)
}

/**
 * 新增激活码
 * @export
 * @returns
 */
export function createActivation(params?: any, option?: ParamOption){
  return POST('/api/v1/activation', arguments)
}

/**
 * 修改激活码批次状态
 * @export
 * @returns
 */
export function editActivationStatus(params?: any, option?: ParamOption){
  return PUT(`/api/v1/activation/${params.activationBatchId}`, arguments)
}

/**
 * 按批次号id查询激活码信息
 * @export
 * @returns
 */
export function getActivationList(params?: any, option?: ParamOption){
  return GET(`/api/v1/activation/${params.activationBatchId}/${params.page}/${params.size}`, arguments)
}

/**
 * 删除激活码批次
 * @export
 * @returns
 */
export function deleteActivation(params?: any, option?: ParamOption){
  return DELETE(`/api/v1/activation/${params.activationBatchId}/user/${params.userId}`, arguments)
}


/**
 * 按教材id查询资源包信息
 * @export
 * @returns
 */
export function getBookResource(params?: any, option?: ParamOption){
  return GET('/api/v1/bookResource', arguments)
}

/**
 * 新增教材资源包
 * @export
 * @returns
 */
export function createBookResource(params?: any, option?: ParamOption){
  return POST('/api/v1/bookResource', arguments)
}

/**
 * 根据资源包id修改资源包信息
 * @export
 * @returns
 */
export function editBookResource(params?: any, option?: ParamOption){
  return PUT(`/api/v1/bookResource/${params.bookResourceId}`, arguments)
}

/**
 * 根据资源包id删除资源
 * @export
 * @returns
 */
export function deleteBookResource(params?: any, option?: ParamOption){
  return DELETE(`/api/v1/bookResource/${params.bookResourceId}/user/${params.userId}`, arguments)
}

/**
 * 查询书架列表
 * @export
 * @returns
 */
export function getBookShelf(params?: any, option?: ParamOption){
  return GET('/api/v1/bookShelf', arguments)
}


/**
 * 添加教材至书架
 * @export
 * @returns
 */
export function createBookShelf(params?: any, option?: ParamOption){
  return POST('/api/v1/bookShelf', arguments)
}

/**
 * 书架移除指定教材
 * @export
 * @returns
 */
export function deleteBookShelf(params?: any, option?: ParamOption){
  return DELETE(`/api/v1/bookShelf/${params.bookId}/user/${params.userId}`, arguments)
}


/**
 * 查询教材版本记录
 * @export
 * @returns
 */
export function getBookVersion(params?: any, option?: ParamOption){
  return GET('/api/v1/bookVersion', arguments)
}

/**
 * 发布教材新版本
 * @export
 * @returns
 */
export function createBookVersion(params?: any, option?: ParamOption){
  return POST('/api/v1/bookVersion', arguments)
}



















