import { GET, ParamOption, POST, PUT, DELETE, PATCH } from '@/httpService/axios'


export function subsystemList() {
  return GET('/subsystem', arguments)
}
export function subsystemCreate(params?: any ) {
  return POST('/subsystem', arguments)
}
export function subsystemInfo( params?: any ) {
    return GET(`/subsystem/${params.id}`, arguments)
}



// 导航相关列表
export function getNavTree(params?: any) {
    return GET(`/nav/tree/${params.sysId}`, arguments)
}
// 导航添加
export function addNavTree() {
    return POST('/nav', arguments)
}
// 获取导航详情
export function getNavInfo() {
    return GET('/nav', arguments)
}
// 更新导航
export function updateNav() {
    return PUT('/nav', arguments)
}
// 删除导航
export function deleteNav() {
    return DELETE('/nav', arguments)
}
// 导航排序
export function sortNav(params?: any) {
    return PATCH(`/nav/${params.id}/sort/${params.sortData}`, arguments)
}
// 切换导航开关
export function switchNav(params?: any) {
    return PATCH(`/nav/${params.id}/sort/${params.sortData}`, arguments)
}

export function gethNavPower(params?: any, options?: ParamOption) {
    return GET(`/power/nav/${params.id}`, [, options])
}

export function updateNavPower(params?: any, options?: ParamOption) {
    return PUT(`/power/nav/${params.id}`, arguments)
}



