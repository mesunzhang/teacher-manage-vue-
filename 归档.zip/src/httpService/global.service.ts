import { GET, ParamOption } from '@/httpService/axios'
import router from '@/router/asyncPermission';

/**
 * 查询所有年级
 * @export
 * @returns
 */
export function getGrade(options?: ParamOption) {
  return GET('/api/v1/dictionary/grade', [, options])
}

/**
 * 查询所有出版社
 * @export
 * @returns
 */
export function getPress(options?: ParamOption) {
  return GET('/api/v1/dictionary/press', [, options])
}

/**
 * 查询所有学科
 * @export
 * @returns
 */
export function getSubject(options?: ParamOption) {
  return GET('/api/v1/dictionary/subject', [, options])
}



export function getHomeList(options?: ParamOption) {
  return GET('/init/portal', [, options])
}


export function getLeftNavList(options?: ParamOption) {
  return  router
}


export function getQuickList(options?: ParamOption) {
  return GET('/init/quick', [, options])
}

export function getAuthList(options?: ParamOption) {

  return GET('/init/auth', [, options]).then(() => {
    return [
      {
        'key': 1,
        'title': '权限管理',
        'tag': 'rule',
        'attachPower': [],
        'children': [
          {
            'key': 2,
            'title': '角色列表',
            'tag': 'group',
            'attachPower': [
              {
                'name': '新增',
                'tag': 'group.add'
              },
              {
                'name': '编辑',
                'tag': 'group.edit'
              },
              {
                'name': '删除',
                'tag': 'group.del'
              }
            ]

          },
          {
            'key': 3,
            'title': '用户列表',
            'tag': 'user',
            'attachPower': [
              {
                'name': '编辑',
                'tag': 'user.edit',
                'auth': false
              }
            ]
          }
        ]

      },
      {
        'key': 4,
        'title': '系统设置',
        'tag': 'setting',
        'attachPower': [],
        'children': [
          {
            'key': 5,
            'title': '导航设置',
            'tag': 'nav',
            'attachPower': [
              {
                'name': '增加',
                'tag': 'nav.add'
              },
              {
                'name': '编辑',
                'tag': 'nav.edit'
              },
              {
                'name': '删除',
                'tag': 'nav.del'
              }
            ]
          },
          {
            'key': 6,
            'title': '权限设置',
            'tag': 'auth',
            'attachPower': [
              {
                'name': '编辑',
                'tag': 'power.edit'
              }
            ]
          }
        ]
      }
    ]
  })
}