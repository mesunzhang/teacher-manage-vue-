import { GET, ParamOption, POST } from '@/httpService/axios'

export function Login(params?: any, option?: ParamOption) {
  return POST('/login', arguments)
}
export function logout(options?: ParamOption) {
  return GET('/login/logout', [,options])
}
export function sendCode(params?: any, option?: ParamOption) {
  return GET('/login/code', arguments)
}

export function getUserInfo() {
  return GET('/userInfo', arguments)
}