import axios, { AxiosError, AxiosResponse, AxiosTransformer } from 'axios'
import { message } from 'ant-design-vue'

import store from '@/store'
import router from '@/router'
axios.defaults.timeout = 15000
const Axios: AxiosTransformer = axios

export interface ParamOption {
  load?: boolean; // 接口请求过程中 是否显示 load
  loadNoClose?: boolean; // load true的情况下    请求完成也不关闭load
  successMsg?: string | boolean; // 请求成功 提示信息  默认false不提示  string:'信息'   true：显示后端信息
  errorMsg?: boolean | string; // 错误信息   默认true 显示后端错误信息,  string:信息    false 不提示
  bolb?: boolean; // 后端传输二进制数据
  error?: (errorText: string) => void
  finally?: () => void
}

export interface ErrorResponse {
  code: number;
  description: string;
  msg: string;
  traceId: string;
}

export function GET(url: string, params: any = []) {
  return fetch(url, 'get', params[0], params[1])
}
export function POST(url: string, params: any = []) {
  return fetch(url, 'post', params[0], params[1])
}
export function DELETE(url: string, params: any = []) {
  return fetch(url, 'delete', params[0], params[1])
}
export function PATCH(url: string, params: any = []) {
  return fetch(url, 'patch', params[0], params[1])
}
export function PUT(url: string, params: any = []) {
  return fetch(url, 'put', params[0], params[1])
}

function fetch(url: string, method: string, params: any , option: ParamOption = <ParamOption>{}) {
  if (option.load) {
    store.commit('setLoading', true)
  }
  let request: any = {
    method: method,
    url: url
  }
  if (/get/i.test(method)) {
    request.params = params
  } else {
    request.data = params
  }
  if (option.bolb) {
    request.responseType = 'blob'
    request.emulateJSON = true
  }

  return Axios(request).then(({ data: res }: AxiosResponse) => {
    if (option.load && !option.loadNoClose) {
      store.commit('setLoading', false)
    }
    if (option.successMsg)
      message.success(typeof option.successMsg === 'string' ? option.successMsg : res.msg)
    option.finally&&option.finally()
    return res
  }).catch(({ response }: { response: AxiosResponse<ErrorResponse> }) => {
    response = response||{}
    store.commit('setLoading', false)
    const errorMsg: any = option.errorMsg || (response.data&&response.data.msg) || codeError(response.status) || response.statusText ||'未知错误'
    if (option.errorMsg !== false) {
      message.error(errorMsg)
    }
    option.error&&option.error(errorMsg)
    option.finally&&option.finally()
    switch (response.status) {
      case 401:
        // router.push('/login')
        break
    }
    return Promise.reject(errorMsg)
  })
}


function codeError(code: number): string | undefined {
  switch (code) {
    case 404:
      return '404找不到'
    case 401:
      return '登录已过期'
    case 500:
    case 502:
    case 504:
      return '服务器错误'
  }
}
