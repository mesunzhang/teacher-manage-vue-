import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
import Nav from './modules/async-router'
import { logout } from '@/httpService/login.service'
import { getAuthList } from '@/httpService/global.service'
import { flatten } from '@/util'

export default new Vuex.Store({
  state: {
    spinning: false, // 全局load状态
    userInfo: {}, // 用户登录信息
    auths: []
  },
  getters: {
    // auths 一维化   {[tag]: [attachPower]}
    sequenceAuths: state => {
      return Object.assign({}, ...flatten(state.auths).map((i: any) => {
        return {
          [i.tag]: i.attachPower
        }
      }))
    },
    // 所有路由权限标识
    routerTag: (state, getters) => {
      return Object.keys(getters.sequenceAuths)
    }
  },
  mutations: {
    login(state, data) {
      state.userInfo = data
    },
    logout(state, data) {
      state.userInfo = {}
      localStorage.removeItem('auth-token')
    },
    setLoading(state, data) {
      state.spinning = data
    },
    saveAuth(state, data) {
      state.auths = data
    }
  },
  actions: {
    async logout({ commit }) {
      await logout({ load: true, successMsg: true })
      commit('logout')
    },
    async getAuthList({ commit, getters ,state}) {
      if(state.auths.length){
        return
      }
      const res = await getAuthList()
      commit('saveAuth', res)
    }

  },
  modules: {
    Nav
  }
})
