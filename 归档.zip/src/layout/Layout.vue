<template>
  <a-layout
    class="layout"
    id="components-layout-demo-custom-trigger"
  >
    <a-layout-sider
      v-model="collapsed"
      :trigger="null"
      collapsible
    >
      <div class="logo"></div>
      <!-- <NavLayout></NavLayout> -->
    </a-layout-sider>
    <a-layout>
      <a-layout-header style="background: #fff; padding: 0;display:flex;justify-content: space-between">
        <a-icon
          class="trigger"
          :type="collapsed ? 'menu-unfold' : 'menu-fold'"
          @click="() => (collapsed = !collapsed)"
        />
        <!-- 用户头像 -->
        <a-dropdown>
          <a
            class="ant-dropdown-link"
            @click="e => e.preventDefault()"
          >
            <a-avatar
              style="backgroundColor:#87d068"
              icon="user"
            />
            <a-icon
              style="margin: 0 20px"
              type="down"
            />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">修改密码</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">退出</a>
            </a-menu-item>
            <!-- <a-menu-item>
              <a href="javascript:;">3rd menu item</a>
            </a-menu-item> -->
          </a-menu>
        </a-dropdown>
      </a-layout-header>
      <a-layout-content :style="{ margin: '24px 16px', padding: '24px', background: '#fff', minHeight: '280px' }">
        <router-view></router-view>
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>
<script lang="ts">
import { Component, Ref, Vue, Watch } from "vue-property-decorator";
// import NavLayout from "@/components/LeftNav";

@Component({
  components: {
    // NavLayout,
  },
})
export default class Layout extends Vue {
  collapsed: boolean = false;
}
</script>
<style>
.layout {
  min-height: 100% !important;
  /* overflow:hidden */
}
#components-layout-demo-custom-trigger .trigger {
  font-size: 18px;
  line-height: 64px;
  padding: 0 24px;
  cursor: pointer;
  transition: color 0.3s;
}

#components-layout-demo-custom-trigger .trigger:hover {
  color: #1890ff;
}

#components-layout-demo-custom-trigger .logo {
  height: 32px;
  background: rgba(255, 255, 255, 0.2);
  margin: 16px;
}
</style>