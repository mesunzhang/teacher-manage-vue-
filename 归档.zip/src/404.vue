<template>
    <a-result status="404" title="404" sub-title="很抱歉，页面未找到">
        <template #extra>
            <a-button type="primary" @click="hrefTo('/',0)">
               返回主页
            </a-button>
        </template>
    </a-result>
</template>
