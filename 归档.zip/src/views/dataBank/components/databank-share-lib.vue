<template>
  <a-modal
    ref="shareFileEdit"
    :visible="visible"
    @ok="submit"
    @cancel="close"
    title="分享"
  >
    <a-form-model>
      <a-form-model-item>
        <a-checkbox-group
          v-model="selectedShareType"
          name="shareFileGroup"
        >
          <a-checkbox
            :value="1"
            :disabled="selectedFilesHasFolder"
          >校本<span class="type-des">
              （只能分享文件、本校内可见）
            </span></a-checkbox><br /><br />
          <a-checkbox
            :value="2"
            :disabled="selectedFilesHasFolder"
          >共享资源<span class="type-des">（只能分享文件、全平台用户可见）</span></a-checkbox><br /><br />
          <a-checkbox
            :value="3"
            :disabled="selectedFilesHasFolder"
          >指定学校校本<span class="type-des">（只能分享文件、指定学校可见）</span></a-checkbox><br /><br />
          <template v-if="selectedShareType.includes(3)">
            <a-select
              mode="multiple"
              label-in-value
              :value="shareSchool.selectedSchools"
              placeholder="搜索学校"
              style="width: 300px"
              :filter-option="false"
              :not-found-content="
								shareSchool.fetching ? undefined : null
							"
              @search="getSchoolList"
              @change="handleChange"
            >
              <a-spin
                v-if="shareSchool.fetching"
                slot="notFoundContent"
                size="small"
              />
              <a-select-option
                v-for="sc in shareSchool.schoolList"
                :key="sc.id"
              >
                {{ sc.name }}
              </a-select-option>
            </a-select><br /><br />
          </template>
          <a-checkbox :value="4">年级共享库<span class="type-des">（可开放给年级学生查看）</span></a-checkbox><br /><br />
          <template v-if="selectedShareType.includes(4)">
            <a-select
              style="width: 120px"
              allowClear
              v-model="shareGrade.subjectId"
              @change="getFolder"
            >
              <a-select-option
                v-for="sub in shareGrade.subject"
                :key="sub.id"
                :value="sub.id"
              >
                {{ sub.name }}
              </a-select-option>
            </a-select>
            <a-tabs
              v-model="shareGrade.gradeId"
              @change="getFolder"
            >
              <a-tab-pane
                :key="grade.id"
                :tab="grade.name"
                v-for="grade in shareGrade.gradeList"
              >
                <Deep
                  :folderList="shareGrade.folderList"
                  @selectTree="selectTargetFilePath"
                  :selectedTree="
										shareGrade.selectedTargetFilePath
									"
                ></Deep>
              </a-tab-pane>
            </a-tabs>
          </template>
        </a-checkbox-group>
      </a-form-model-item>
    </a-form-model>
  </a-modal>
</template>
<script>
import Deep from "@/components/powerControl/deep.vue";
import PowerApi from "@/api/powerControl";
import { shareFile, shareFileToGrade, getShareGradeList } from "@/api/dataBank";
import { resourse } from "../mixins";
import debounce from "lodash/debounce";

export default {
  props: {
    visible: {
      type: Boolean,
      default: false,
      required: false,
    },
    selectedShareFileIds: {
      type: Array,
      default: [],
      required: true,
    },
    selectedFilesHasFolder: {
      type: Boolean,
      default: false,
      required: true,
    },
    subjectId: {
      required: true,
    },
    isShare: {
      type: Boolean,
      required: false,
    },
  },
  components: {
    Deep,
  },
  data() {
    this.lastFetchId = 0;
    this.getSchoolList = debounce(this.getSchoolList, 800);

    return {
      selectedShareType: [],
      shareSchool: {
        schoolList: [],
        selectedSchools: [],

        fetching: false,
      },
      shareGrade: {
        subject: JSON.parse(window.sessionStorage.commonList).subject,
        gradeList: [],
        folderList: [],
        selectedTargetFilePath: [],
        gradeId: "",
        subjectId: "",
      },
    };
  },
  watch: {
    isShare(newVal) {
      if (newVal) {
        this.selectedShareType.push(2);
      }
    },
    selectedShareType(newVal, oldVal) {
      if (newVal.includes(4)) {
        this.shareGrade.subjectId = this.subjectId
          ? this.subjectId
          : this.shareGrade.subject[0].id;
        this.getShareGradeList();
      }
    },
  },
  methods: {
    getShareGradeList() {
      getShareGradeList({ name: "base" }).then((res) => {
        this.shareGrade.gradeList = res.grades;
        this.shareGrade.gradeId = res.grades.length > 0 ? res.grades[0].id : "";
        this.getFolder();
      });
    },
    /**
     * 获取共享目录树结构
     * @function {function name}
     * @return {type} {description}
     */
    getFolder() {
      this.shareGrade.folderList = [];
      PowerApi.getShareFolderList({
        gradeId: this.shareGrade.gradeId,
        subjectId: this.shareGrade.subjectId,
      }).then((res) => {
        this.shareGrade.folderList = res;
      });
    },
    selectTargetFilePath(params) {
      this.shareGrade.selectedTargetFilePath = params;
    },

    //搜索学校列表
    getSchoolList(value) {
      this.lastFetchId += 1;
      const fetchId = this.lastFetchId;
      this.shareSchool.schoolList = [];
      this.shareSchool.fetching = true;
      PowerApi.getSchoolList({ keywords: value }).then((res) => {
        this.shareSchool.schoolList = res.data.list;
        this.shareSchool.fetching = false;
      });
    },
    handleChange(value) {
      Object.assign(this.shareSchool, {
        selectedSchools: value,
        schoolList: [],
        fetching: false,
      });
    },
    submit() {
      let requestArray = [];

      let tempArr = [...this.selectedShareType];
      if (this.selectedShareType.includes(4)) {
        tempArr.splice(tempArr.indexOf(4), 1);
      }
      requestArray.push(this.shareFile());
      if (this.selectedShareType.includes(4)) {
        requestArray.push(this.shareFileToGrade());
      }

      // requestArray.push(this.shareFile());
      // requestArray.push(this.shareFileToGrade());
      Promise.all(requestArray).then((res) => {
        this.close();
        this.$emit("refreshDataList");
      });
    },
    shareFile() {
      return new Promise((resolve, reject) => {
        shareFile({
          resourceIdList: this.selectedShareFileIds,
          type: this.selectedShareType,
          schoolIdList: this.shareSchool.selectedSchools.map(
            (item) => item.key
          ),
        }).then((res) => {
          resolve();
        });
      });
    },
    shareFileToGrade() {
      return new Promise((resolve, reject) => {
        shareFileToGrade({
          folderId:
            this.shareGrade.selectedTargetFilePath.length == 1
              ? this.shareGrade.selectedTargetFilePath[0]
              : "0",
          resourceIdList: this.selectedShareFileIds,
          shareGradeId: this.shareGrade.gradeId,
          shareSubjectId: this.shareGrade.subjectId,
        }).then((res) => {
          resolve();
        });
      });
    },
    close() {
      this.selectedShareType = [];
      this.shareSchool.selectedSchools = [];
      this.shareGrade.selectedTargetFilePath = [];
      this.$emit("update:visible", false);
    },
  },
};
</script>
<style lang="less" scoped>
.type-des {
  color: #999999;
}
</style>
