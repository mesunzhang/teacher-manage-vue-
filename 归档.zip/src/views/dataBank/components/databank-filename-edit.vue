<template>
  <div>
    <a-modal
      ref="editFile"
      :visible="visible"
      :title="editType == 'add' ? '新建' : '修改'"
      @ok="submit"
      @cancel="handleClose"
    >
      <a-form-model
        :model="dataForm"
        :labelCol="{ span: 3 }"
        :wrapperCol="{ span: 14 }"
      >
        <a-form-model-item
          label="名称"
          v-if="canEditName"
        >
          <a-input
            ref="name"
            :maxLength="50"
            v-model="dataForm.name"
          />
        </a-form-model-item>
        <a-form-model-item
          label="学科"
          v-if="canEditSubject || !canEditName"
        >
          <a-select
            style="width: 120px"
            v-model="dataForm.subject"
          >
            <a-select-option
              v-for="sub in subject"
              :key="sub.id"
              :value="sub.id"
            >
              {{ sub.name }}
            </a-select-option>
          </a-select>
        </a-form-model-item>
      </a-form-model>
    </a-modal>
  </div>
</template>
<script>
import { addFolder, editFilename, editFile } from "@/api/dataBank";
export default {
  props: {
    visible: {
      type: Boolean,
      default: false,
      required: false,
    },
    editType: {
      type: String,
      default: "add",
      required: false,
    },
    editForm: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      dataForm: {},
      subject: JSON.parse(window.sessionStorage.commonList).subject,
    };
  },
  computed: {
    canEditSubject() {
      return this.dataForm.isdir === 1 && this.editType == "edit";
    },
    canEditName() {
      return !Array.isArray(this.dataForm.id);
    },
  },
  watch: {
    visible(newVal, oldVal) {
      if (newVal) {
        //等待弹框显示后，再进行名称输入框聚焦
        this.dataForm = { ...this.editForm };
        this.$nextTick(() => {
          this.$nextTick(() => {
            if (this.$refs.name) {
              this.$refs.name.focus();
            }
          });
        });
      }
    },
  },
  methods: {
    handleClose() {
      this.$refs.editFile.resetFields;
      this.$emit("update:visible", false);
    },
    submit() {
      console.log(this.canEditSubject);
      if (this.editType == "add") {
        //新建文件夹
        addFolder({
          parentId: this.dataForm.parentId,
          fileName: this.dataForm.name,
        }).then((res) => {
          this.$emit("refreshDataList");
        });
      } else {
        //修改
        //1.针对单个文件夹只修改文件名;文件名有修改才提交
        if (
          this.canEditName &&
          !this.canEditSubject &&
          this.dataForm.name != this.editForm.name
        ) {
          editFilename({
            personFileId: this.dataForm.id,
            fileName: this.dataForm.name,
          }).then((res) => {
            this.$emit("refreshDataList");
          });
        }
        //2.单个文件修改文件名和学科
        else if (this.canEditName && this.canEditSubject) {
          editFile({
            resourceIdList: [this.dataForm.id],
            subjectId: this.dataForm.subject,
            name: this.dataForm.name,
            action: "editUserFile",
            privateFlag: false,
          }).then((res) => {
            this.$emit("refreshDataList");
          });
        }
        //3.多个文件只能修改学科
        else if (!this.canEditName) {
          editFile({
            resourceIdList: this.dataForm.id,
            subjectId: this.dataForm.subject,
            name: "",
            action: "editUserFile",
            privateFlag: false,
          }).then((res) => {
            this.$emit("refreshDataList");
          });
        }
      }
      this.handleClose();
    },
  },
};
</script>
