<template>
  <div class="dataBank">
    <div
      class="dataBank_main"
      :class="{ showTree: showTree }"
    >
      <div class="folderList">
        <div class="folderList_main">
          <div class="tree">
            <Deep
              ref="folderTree"
              :folderList="folderList"
              @selectTree="selectTree"
              :selectedTree="selectedTree"
              v-if="folderList.length > 0"
            ></Deep>
            <!-- </a-tree-node>
						</a-tree> -->
          </div>
        </div>
      </div>
      <div class="fileContainer">
        <div class="fileContainer_main">
          <div class="tab">
            <div class="button-group">
              <div class="button_left">
                <a-button
                  class="button"
                  type="primary"
                  @click="uploadFile"
                >上传文件</a-button>
                <a-button
                  class="button"
                  @click="addFilename()"
                  :disabled="diableAddFolder"
                >新建文件夹</a-button>
                <a-button-group class="sub-group">
                  <a-tooltip
                    placement="topLeft"
                    title="分享"
                  >
                    <a-button
                      class="button"
                      :disabled="
												selectedRowKeys.length == 0
											"
                      @click="shareFile()"
                    >
                      <img
                        src="@/assets/img/dataBank/ic_share.png"
                        alt=""
                      />
                    </a-button>
                  </a-tooltip>
                  <a-tooltip
                    placement="topLeft"
                    title="移动到"
                  >
                    <a-button
                      class="button"
                      :disabled="
												selectedRowKeys.length == 0
											"
                      @click="moveFile()"
                    >
                      <img
                        src="@/assets/img/dataBank/ic_move.png"
                        alt=""
                      />
                    </a-button>
                  </a-tooltip>
                  <a-tooltip
                    placement="topLeft"
                    title="下载"
                  >
                    <a-button
                      class="button"
                      :disabled="
												selectedRowKeys.length == 0
											"
                      @click="downloadFolder()"
                    >
                      <img
                        src="@/assets/img/dataBank/ic_download.png"
                        alt=""
                      />
                    </a-button>
                  </a-tooltip>
                  <a-dropdown
                    :overlayClassName="'dropdown'"
                    :disabled="selectedRowKeys.length == 0"
                  >
                    <a-menu slot="overlay">
                      <a-menu-item key="1">
                        <a-button
                          :disabled="
														selectedRowKeys.length ==
															0
													"
                          @click="editFilename()"
                          type="link"
                        >编辑
                        </a-button>
                      </a-menu-item>
                      <a-menu-item key="2">
                        <a-popconfirm
                          v-if="isFolder"
                          title="删除文件夹会删除其下所有文件，确定要删除吗？"
                          ok-text="确定"
                          cancel-text="取消"
                          @confirm.stop="
														deleteFolder()
													"
                        >
                          <a-button
                            type="link"
                            :disabled="
															selectedRowKeys.length ==
																0
														"
                          >删除
                          </a-button>
                        </a-popconfirm>
                        <a-button
                          v-else
                          type="link"
                          :disabled="
														selectedRowKeys.length ==
															0
													"
                          @click="deleteFolder()"
                        >删除
                        </a-button>
                      </a-menu-item>
                      <!-- <a-menu-item key="3">
												<a-button
													type="link"
													:disabled="
														selectedRowKeys.length ==
															0
													"
													@click="unShareFile()"
													>取消共享
												</a-button>
											</a-menu-item> -->
                    </a-menu>
                    <a-button class="button">
                      <img
                        src="@/assets/img/dataBank/ic_more.png"
                        alt=""
                      />
                    </a-button>
                  </a-dropdown>
                </a-button-group>
              </div>
              <div class="button_right">
                <a-input
                  placeholder="搜索文件名"
                  class="input"
                  v-model="formData.name"
                  @pressEnter="getUserResource"
                >
                  <img
                    slot="prefix"
                    src="@/assets/img/dataBank/ic_input_search.png"
                    alt=""
                  />
                </a-input>
                <a-button
                  class="button"
                  @click="goPowerControl"
                >
                  资料管控
                </a-button>
              </div>
            </div>
            <div>
              <a-table
                :columns="columns"
                :data-source="tableData"
                rowKey="id"
                :customRow="tableHandle"
                :row-selection="{
									onChange: selectChange,
									selectedRowKeys: selectedRowKeys
								}"
                :pagination="pagination"
                @change="onChange"
              >
                <template
                  slot="name"
                  slot-scope="text, record"
                >
                  <div style="
											width: 100%;
											max-width: 370px;
											cursor: pointer;
											height: 32px;
											line-height: 32px;
										">
                    <!-- 文件夹 -->
                    <img
                      src="@/static/common/ic_wenjianjia.png"
                      v-if="record.isdir == 2"
                      alt=""
                      style="
												width: 16px;
												height: 16px;
												margin-right: 8px;
											"
                      @click.stop="selectFolder(record)"
                    />
                    <!-- 文件 -->
                    <img
                      v-else
                      :src="returnSrc(record)"
                      alt=""
                      style="
												width: 16px;
												height: 16px;
												margin-right: 8px;
											"
                      @click.stop="openFile(record.id)"
                    />
                    <!-- 展示文字 -->
                    <span
                      class="tableSubName"
                      @click.stop="
												record.isdir == 2
													? selectFolder(record)
													: openFile(record.id)
											"
                    >{{ text }}</span>

                    <a-tag
                      v-if="record.inSchool"
                      class="tag-xb"
                    >校本</a-tag>
                    <a-tag
                      v-if="record.publicStatus"
                      class="tag-gx"
                    >共享资源</a-tag>
                    <a-tag
                      v-if="record.shareCreatorName"
                      class="tag-ux"
                    >{{
												record.shareCreatorName
											}}共享</a-tag>
                    <!-- 小菜单 -->
                    <div class="showedMenu">
                      <a-button
                        @click.stop="shareFile(record)"
                        type="link"
                      ><img
                          src="@/assets/img/dataBank/ic_folder_share_b.png"
                          alt=""
                        />
                      </a-button>

                      <a-button
                        @click.stop="
													downloadFolder(record)
												"
                        type="link"
                      ><img
                          src="@/assets/img/dataBank/ic_download_blue.png"
                          alt=""
                        />
                      </a-button>
                      <a-button
                        @click.stop="
													editFilename(record)
												"
                        type="link"
                      ><img
                          src="@/assets/img/dataBank/download_blue.png"
                          alt=""
                        />
                      </a-button>
                      <a-dropdown
                        :overlayClassName="'dropdown'"
                        @visibleChange="
													flag => {
														changeItemShowMenu(
															record,
															flag
														);
													}
												"
                      >
                        <a-menu slot="overlay">
                          <a-menu-item key="1">
                            <a-button
                              type="link"
                              @click="
																moveFile(record)
															"
                            >
                              移动到</a-button>
                          </a-menu-item>
                          <a-menu-item key="2">
                            <a-popconfirm
                              v-if="
																record.isdir ===
																	2
															"
                              title="删除文件夹会删除其下所有文件，确定要删除吗？"
                              ok-text="确定"
                              cancel-text="取消"
                              @confirm.stop="
																deleteFolder(
																	record
																)
															"
                            >
                              <a-button type="link">删除
                              </a-button>
                            </a-popconfirm>
                            <a-button
                              v-else
                              type="link"
                              @click="
																deleteFolder(
																	record
																)
															"
                            >删除
                            </a-button>
                          </a-menu-item>
                          <a-menu-item key="3">
                            <a-button
                              type="link"
                              @click="
																openSaveToBook(
																	record
																)
															"
                            >转存到书内</a-button>
                          </a-menu-item>
                        </a-menu>
                        <img
                          src="@/assets/img/dataBank/ic_more_blue.png"
                          alt=""
                        />
                      </a-dropdown>
                    </div>
                  </div>
                </template>

                <template
                  slot="subject"
                  slot-scope="subject"
                >
                  <div>
                    {{ subject | getSubjectNameById }}
                  </div>
                </template>
                <div
                  slot="filterDropdown"
                  style="padding: 8px"
                >
                  <a-select
                    style="width: 120px"
                    allowClear
                    v-model="formData.subjectId"
                    @change="getUserResource"
                  >
                    <a-select-option
                      v-for="sub in subject"
                      :key="sub.id"
                      :value="sub.id"
                    >
                      {{ sub.name }}
                    </a-select-option>
                  </a-select>
                </div>
                <span
                  class="triangle-arrow"
                  slot="filterIcon"
                ></span>

                <!-- <a-icon
									slot="filterIcon"
									slot-scope="filtered"
									type="down"
									:style="{
										color: filtered ? '#108ee9' : undefined
									}"
								/> -->
                <template
                  slot="fileLength"
                  slot-scope="file, record"
                >
                  <div v-if="record.isdir == 2">--</div>
                  <div v-else>
                    {{ file }}
                  </div>
                </template>
                <template
                  slot="rangeName"
                  slot-scope="rangeName"
                >
                  <div>
                    {{ rangeName }}
                  </div>
                </template>

                <template
                  slot="createTime"
                  slot-scope="time"
                >
                  <div>
                    {{ time }}
                  </div>
                </template>
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <settingModal
      :type="openType"
      v-model="openVisible"
      :openClassList="openClassList"
      :selectedTabsValue="selectedTabsValue"
      @change="setting"
    ></settingModal>
    <filename-edit
      ref="editModel"
      :visible.sync="filenameModalVisible"
      :editType="editType"
      :editForm="editForm"
      @refreshDataList="refreshDataList"
    ></filename-edit>
    <!--移动文件、文件夹 -->
    <a-modal
      ref="moveFileEdit"
      :visible="moveFileEditVisible"
      @ok="submitMoveFile"
      @cancel="closeMoveFileModal"
    >
      <a-form-model
        :labelCol="{ span: 3 }"
        :wrapperCol="{ span: 14 }"
      >
        <a-form-model-item>
          <Deep
            :folderList="folderList"
            @selectTree="selectTargetFilePath"
            :selectedTree="selectedTargetFilePath"
            v-if="folderList.length > 0"
          ></Deep>
        </a-form-model-item>
      </a-form-model>
    </a-modal>
    <!-- 分享文件、文件夹 -->
    <share-lib
      ref="shareFileLib"
      :visible.sync="shareFileVisible"
      :selectedShareFileIds="selectedShareFileIds"
      :selectedFilesHasFolder="selectedFilesHasFolder"
      :subjectId="userInfo ? userInfo.subjectId : ''"
      :isShare="isShare"
      @refreshDataList="refreshDataList"
    ></share-lib>
    <!-- 上传文件 -->
    <a-modal
      ref="uploadFile"
      width="60%"
      :visible="uploadFileVisible"
      @cancel="uploadFileVisible = false"
      title="上传"
    >
      <a-form-model>
        <uploadFile
          v-if="reset === true"
          :subjectId="userInfo ? userInfo.subjectId : ''"
          :parentId="selectedTree.length == 0 ? '0' : selectedTree[0]"
          @getFilesList="closeUploadFileModal"
        ></uploadFile>
      </a-form-model><template slot="footer"><span></span>
      </template>
    </a-modal>
    <a-modal
      :visible="moveVisible"
      :width="800"
      @ok="saveToBook"
      @cancel="moveCancel"
    >
      <SaveToBookComponent ref="savetobook" />
    </a-modal>
  </div>
</template>

<script>
import PowerApi from "../../api/powerControl";
import commonApi from "@/api/commonApi";
import SettingModal from "../../components/public/settingModal";
import Deep from "@/components/powerControl/deep.vue";
import powerControl from "../../api/powerControl";
import { resourse } from "./mixins";
import SaveToBookComponent from "../SaveToBook";
//增删改查接口
import {
  getUserResource,
  deleteFolder,
  downloadFile,
  downloadByUrl,
  moveFile,
  unShareFile,
  savePersonResourceToBook,
} from "@/api/dataBank";
//编辑文件名组件
import filenameEdit from "./components/databank-filename-edit";
//上传文件组件
import uploadFile from "@/components/uploadFile";
//共享-年级共享
import shareLib from "./components/databank-share-lib";
export default {
  mixins: [resourse],
  components: {
    SettingModal,
    Deep,
    filenameEdit,
    uploadFile,
    shareLib,
    SaveToBookComponent,
  },
  data() {
    return {
      reset: false,
      userInfo: {},
      // 显示小菜单
      showedMenu: false,
      selectedTabsValue: " ",
      showTree: false,
      tableData: [],
      openType: "",
      openVisible: false,
      showSettingModal: true,
      folderList: [],
      classList: [],
      formData: {
        page: 1,
        size: 20,
        isShowPrivilege: true,
        classId: " ",
        name: "", //根据文件夹名进行搜索
        subjectId: "", //根据科目进行搜索
      },
      menuList: [
        { name: "全部", id: 0 },
        { name: "长期公开", id: 1 },
        { name: "限时公开的", id: 2 },
        { name: "未公开的", id: 3 },
      ],
      selectName: "全部",
      // 公开 || 关闭
      settingFormData: {
        resourceList: [],
        selectAll: false,
      },
      //选中的成员id列表
      selectedRowKeys: [],
      //选中的成员列表
      selectedRows: [],
      pagination: {
        current: 1,
        total: 0,
        pageSize: 20,
        showSizeChanger: true,
        itemRender: this.itemRender,
      },
      openClassList: [],
      selectedTree: [],
      filenameModalVisible: false,
      editType: "",
      editForm: {},
      //移动文件、文件夹
      moveFileEditVisible: false,
      selectedTargetFilePath: [],
      selectedMoveFileId: "",
      //分享
      shareFileVisible: false,
      selectedShareFileIds: [],
      selectedFilesHasFolder: false,
      //上传文件
      uploadFileVisible: false,
      //三级目录下不能新建文件夹
      diableAddFolder: false,
      moveVisible: false,
      resourceIdList: [],
      isShare: false,
    };
  },
  mounted() {
    window.getFolder = this.getFolder;
    window.selectFolder = this.selectFolder;
    this.getUserInfo();
    this.getFolder();
    this.getClassList();
    this.getUserResource();
    if (this.$route.query.showTree) {
      this.showTree = true;
    }
  },
  computed: {
    isFolder() {
      return (
        this.selectedRows.some((item) => {
          return item.isdir === 2;
        }) || this.selectedRows.length > 1
      );
    },
  },
  watch: {
    userInfo(newVal) {
      this.userInfo = newVal;
    },
  },

  methods: {
    getUserInfo() {
      commonApi.getUserInfo().then((res) => {
        this.userInfo = res;
      });
    },
    goPowerControl() {
      if (
        window.top &&
        window.top.document &&
        window.top.document.querySelector(".layui-tab-title") &&
        window.top.document.querySelector(".files-out")
      ) {
        window.top.document.querySelector(".layui-tab-title").style.display =
          "none";
        window.top.document.querySelector(".files-out").style.display = "none";
      }
      this.$router.push({ path: "/powerControl" });
    },
    // 监听表格成员小菜单旗下的下拉菜单悬浮状态开启或关闭
    changeItemShowMenu(item, status) {
      // 下拉菜单显示
      item.showDrop = status;
      // 小菜单显示
      item.showedMenu = status;
      // 如果小菜单和下拉菜单都为false，则关闭小菜单的显示状态
    },

    //点击行选中控制
    checkSelector(data) {
      let selectedIndex = this.selectedRowKeys.findIndex(
        (item) => item == data.id
      );
      if (selectedIndex == -1) {
        this.selectedRowKeys.push(data.id);
        this.selectedRows.push(data);
      } else {
        this.selectedRowKeys.splice(selectedIndex, 1);
        this.selectedRows.push(selectedIndex, 1);
      }
    },
    openFile(id) {
      // $.ajax({
      //   type: "post",
      //   url: "/resource/Resource/getFileTempUrl",
      //   data: JSON.stringify({
      //     resourceIdList: [id],
      //     requestType: "view",
      //   }),
      //   success: function (res) {
      //     if (res.data[0].resourceType === 9) {
      //       aliplay(res.data[0].resourceId);
      //     } else {
      //       window.open(
      //         "https://play.yunzuoye.net/play?type=" +
      //           res.data[0].resourceType +
      //           "&src=" +
      //           res.data[0].fileUrl
      //       );
      //     }
      //   },
      // });
      // function aliplay(videoId) {
      //   var send = {
      //     videoId: videoId,
      //     mKey: "teacherZtktVideo",
      //   };
      //   if (navigator.userAgent.match(/Android [4-5]/i)) {
      //     $.ajax({
      //       url: "/common/aly/getPlayInfo",
      //       type: "post",
      //       data: JSON.stringify(send),
      //       success: function (res) {
      //         if (res.data.code == "404") {
      //           this.$message.error("视频出错");
      //         } else if (res.data.code == "403") {
      //           this.$message.error("视频正在转码中，请稍后再点击");
      //         } else {
      //           window.open(
      //             "/mobile/resource/play?src=" +
      //               res.data.PlayInfoList.PlayInfo[0].PlayURL +
      //               "&title="
      //           );
      //         }
      //       },
      //     });
      //   } else {
      //     $.ajax({
      //       url: "/common/aly/getPlayAuth",
      //       type: "post",
      //       data: JSON.stringify(send),
      //       success: function (res) {
      //         if (res.data.code == "404") {
      //           this.$message.error("视频出错");
      //         } else if (res.data.code == "403") {
      //           this.$message.error("视频正在转码中，请稍后再点击");
      //         } else {
      //           window.open(
      //             "/mobile/resource/aliplayerVideo?vid=" +
      //               send.videoId +
      //               "&playauth=" +
      //               res.data.PlayAuth +
      //               "&title="
      //           );
      //         }
      //       },
      //     });
      //   }
      // }
    },
    itemRender(current, type, originalElement) {
      if (type === "prev") {
        return `上一页`;
      } else if (type === "next") {
        return `下一页`;
      }
      return originalElement;
    },
    // 进入文件夹
    selectFolder(record) {
      this.diableAddFolder = this.$refs.folderTree.folderLevel[record.id] >= 3;
      this.formData.fileId = record.id;
      this.selectedTree = [record.id];
      // 初始化右侧文件列表
      this.refreshDataList();
    },
    //
    linkToCenter() {
      if (parent) {
        parent.window.location.href = "/resource/Resource/myBook";
      }
    },
    // 公开 或者 关闭 弹出框 确定 操作
    // type==open 公开 type == close 关闭
    setting(params) {
      if (params == false) {
        this.openVisible = false;
        return;
      }

      let formData = { ...this.settingFormData, ...params };
      if (params.type == "open") {
        commonApi.setAuth(formData).then((res) => {
          if (res.code != 200) {
            return;
          }
          this.openVisible = false;
          this.getUserResource();
        });
      } else {
        powerControl.batchClose(formData).then((res) => {
          this.openVisible = false;
          this.getUserResource();
        });
      }
    },

    // 打开关闭||公开弹出框
    openSetting(type) {
      // 分两种情况。
      // 1 全选 存在fileId 不存在 resourceList
      // 2 单选 不存在fileId 存在 resourceList
      if (
        (!this.settingFormData.resourceList && !this.settingFormData.fileId) ||
        (this.settingFormData.resourceList &&
          this.settingFormData.resourceList.length == 0)
      ) {
        return this.$message.error("请先选择文件");
      }
      this.openType = type;
      this.openVisible = true;
    },
    // parent.$('.stuAuth').hide()
    selectTree(params) {
      this.diableAddFolder = this.$refs.folderTree.folderLevel[params[0]] >= 3;
      // this.selectedFolder = this.folderList[0].children.filter(
      // 	item => item.id == params
      // )[0];
      this.formData.fileId = params[0];
      this.formData.page = 1;
      this.pagination.current = 1;
      this.selectedTree = params;
      // 初始化复选框状态
      this.selectChange([], []);
      if (!this.showTree) {
        this.getUserResource();
      }

      if (parent && parent.getFilesList) {
        parent.getFilesList(this.formData.fileId);
      }
    },
    /**
     * 获取左侧目录树结构
     * @function {function name}
     * @return {type} {description}
     */
    getFolder() {
      PowerApi.getFolder().then((res) => {
        res.data = [{ id: "", name: "我的资料库", children: res.data }];
        this.folderList = res.data;
      });
    },
    /**
     * 改变页码
     * @function {function name}
     * @param  {type} selectedRowKeys {description}
     * @return {type} {description}
     */
    onChange(selectedRowKeys) {
      this.pagination = selectedRowKeys;
      this.formData.page = this.pagination.current;
      this.formData.size = this.pagination.pageSize;

      this.refreshDataList();
    },
    /**
     * icon切换
     * @function {function name}
     * @param  {type} item {description}
     * @return {type} {description}
     */
    returnSrc(item) {
      switch (item.resourceType) {
        case 1:
          return require("../../static/common/ic_video.png");
        case 2:
          return require("../../static/common/ic_yinpin.png");
        case 3:
          return require("../../static/common/ic_weike.png");
        case 4:
          return require("../../static/common/ic_weike.png");
        case 5:
          return require("../../static/common/ic_ppt.png");
        case 6:
          return require("../../static/common/ic_word.png");
        case 7:
          return require("../../static/common/ic_img.png");
        case 8:
          return require("../../static/common/ic_pdf.png");
        case 9:
          return require("../../static/common/ic_video.png");
        case 10:
          return require("../../static/common/ic_wenjianjia.png");
      }
    },
    // 改变复选框
    selectChange(indexList, data) {
      this.selectedRows = data;

      this.selectedRowKeys = indexList;
      if (indexList.length == this.tableData.length) {
        this.settingFormData.selectAll = true;
      } else {
        this.settingFormData.selectAll = false;
      }
      // 存储 => 关闭的目录id
      this.settingFormData.fileId = this.selectedTree[0] || " ";
      // 表格不存在数据 || 选中的数据和实际全部的数据不等
      // 传参
      if (data.length !== this.tableData.length || this.tableData.length == 0) {
        this.settingFormData.resourceList = data.map((item) => {
          return { resourceId: item.id, isdir: item.isdir };
        });
      } else {
        // 全选的话，不需要传参(resourceList)
        delete this.settingFormData.resourceList;
      }
      //初始化弹出框
    },

    // 获取班级列表接口
    getClassList() {
      PowerApi.getClassList().then((res) => {
        res.data.unshift({
          className: "全部",
          classId: " ",
          classType: -1,
        });
        this.classList = res.data;
        // 关闭 公开 弹出框 班级列表
        this.openClassList = this.classList.map((item) => {
          return {
            label: item.className,
            value: item.classId,
            classType: item.classType,
          };
        });

        if (this.classList.length == 0 && parent) {
          parent.$(".stuAuth").hide();
        }
      });
    },
    tableHandle(record, index) {
      return {
        on: {
          click: () => {
            this.checkSelector(record);
          },
          mouseenter: () => {
            this.tableData[index].showedMenu = true;
          },
          mouseleave: () => {
            if (this.tableData[index].showDrop) {
            } else {
              this.tableData[index].showedMenu = false;
            }
          },
        },
      };
    },
    // 获取右侧资料列表
    getUserResource() {
      getUserResource(this.formData).then((res) => {
        this.tableData = res.data.list.map((item) => {
          return { ...item, showedMenu: false };
        });
        //临时在资源库页面中去掉文件状态字段的显示;2020.12.3 zyt
        if (
          res.data.list.length > 0 &&
          res.data.list[0].hasOwnProperty("classPublicSettingList")
        ) {
          // 全部班级状态下文件状态字段的展示
          if (this.formData.classId == " ") {
            let arr = ["", "全公开", "部分公开", "未公开"];
            // 因为默认添加了一个全部，所以需要总长度 - 1
            let totalLength = this.classList.length - 1;
            this.tableData.forEach((item) => {
              // 全公开
              if (item.classPublicSettingList.length == totalLength) {
                item.rangeName = arr[1];
                // 未公开
              } else if (item.classPublicSettingList.length == 0) {
                item.rangeName = arr[3];
                // 部分公开
              } else {
                item.rangeName = arr[2];
              }
            });
            // 单个班级状态下文件状态字段的展示
          } else {
            this.tableData.forEach((item) => {
              let index = item.classPublicSettingList.findIndex((findItem) => {
                return findItem.classId == this.formData.classId;
              });
              if (index != -1) {
                item.rangeName =
                  item.classPublicSettingList[index].publicSettingText;
              } else {
                item.rangeName = "未公开";
              }
              // item.rangeName = arr[item.publicRange];
            });
          }
        }
        this.pagination.total = res.data.totalCount;
      });
    },
    //刷新右侧列表；初始化复选框状态
    refreshDataList() {
      this.selectChange([], []);
      this.getFolder();
      this.getUserResource();
    },
    //新建文件夹
    addFilename() {
      this.editType = "add";
      this.editForm = { parentId: this.formData.fileId || 0 };
      this.filenameModalVisible = true;
    },
    //修改文件
    editFilename(data) {
      if (data) {
        this.editForm = data;
      } else if (
        this.selectedRows.length == 1 &&
        this.selectedRows[0].isdir === 1
      ) {
        this.editForm = { ...this.selectedRows[0] };
      } else {
        this.editForm = { id: [...this.selectedRowKeys], name: "" };
      }
      this.editType = "edit";
      this.filenameModalVisible = true;
    },
    //删除文件夹
    deleteFolder(data) {
      let ids = [];
      if (data) {
        ids.push(data.id);
      } else {
        ids = [...this.selectedRowKeys];
      }
      deleteFolder({ resourceIdList: ids }).then((res) => {
        this.refreshDataList();
      });
    },
    //转存到书内
    openSaveToBook(data) {
      this.resourceIdList = [data.id];
      this.moveVisible = true;
      if (this.$refs.savetobook) this.$refs.savetobook.init();
    },
    saveToBook() {
      savePersonResourceToBook({
        ...this.$refs.savetobook.getSelectParam(),
        resourceIdList: this.resourceIdList,
      }).then((res) => {
        if (Array.isArray(res)) {
          this.moveVisible = false;
        }
      });
    },
    moveCancel() {
      let param = this.$refs.savetobook.getSelectParam();
      if (param.targetBookId) this.$refs.savetobook.init();
      else this.moveVisible = false;
    },
    //下载文件/文件夹
    downloadFolder(data) {
      let files = data ? [data] : [...this.selectedRows];
      let ids = files.map((item) => item.id);
      let downloadType =
        files.length == 1 && files[0].isdir == 1 ? "file" : "folder";
      if (downloadType == "file") {
        downloadFile({
          requestType: "download",
          resourceIdList: ids,
        }).then((res) => {
          if (res.data.length > 0) {
            let url = res.data[0].fileUrl;
            let filename = res.data[0].name + "." + res.data[0].extension; //暂时以拼接后缀名的形式处理文件类型，后续要判断MIME类型
            downloadByUrl(url).then((res) => {
              let blob = new Blob([res]);
              let link = document.createElement("a");
              link.href = window.URL.createObjectURL(blob);
              link.download = filename;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              window.URL.revokeObjectURL(link);
            });
          }
        });
      } else if (downloadType == "folder") {
        downloadFile({
          requestType: "batchDownload",
          resourceIdList: ids,
        }).then((res) => {
          if (res.data.length > 0) {
            let url = res.data[0].fileUrl;
            let filename = files[0].name + "等" + files.length + "个文件.zip";
            downloadByUrl(url).then((res) => {
              let blob = new Blob([res]);
              let link = document.createElement("a");
              link.href = window.URL.createObjectURL(blob);
              link.download = filename; //批量下载时，生成zip文件
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              window.URL.revokeObjectURL(link);
            });
          }
        });
      }
    },
    //移动文件、文件夹
    moveFile(data) {
      this.moveFileEditVisible = true;
      if (data) {
        this.selectedMoveFileId = data.id;
      }
    },
    closeMoveFileModal() {
      this.moveFileEditVisible = false;
      this.selectedMoveFileId = "";
      this.selectedTargetFilePath = [];
    },
    selectTargetFilePath(params) {
      this.selectedTargetFilePath = params;
    },
    submitMoveFile() {
      moveFile({
        resourceIdList:
          this.selectedMoveFileId != ""
            ? [this.selectedMoveFileId]
            : this.selectedRowKeys,
        targetResourceIdList: this.selectedTargetFilePath,
      }).then((res) => {
        this.closeMoveFileModal();
        this.refreshDataList();
      });
    },
    //分享文件、文件夹；
    shareFile(data) {
      let selectedFiles = data ? [data] : this.selectedRows;
      this.selectedShareFileIds = selectedFiles.map((item) => item.id);
      this.selectedFilesHasFolder = selectedFiles.some(
        (item) => item.isdir === 2
      );
      if (data) {
        this.isShare = data.publicStatus == 1;
      } else {
        this.isShare = false;
      }
      this.shareFileVisible = true;
    },
    //取消共享
    unShareFile(data) {
      unShareFile({
        resourceIdList: data ? [data.id] : this.selectedRowKeys,
      }).then((res) => {
        this.refreshDataList();
      });
    },
    //上传文件
    uploadFile() {
      this.uploadFileVisible = true;
      this.reset = false;
      this.$nextTick(() => (this.reset = true));
    },
    //关闭上传文件模态框
    closeUploadFileModal() {
      this.uploadFileVisible = false;
      this.refreshDataList();
    },
  },
};
</script>

<style lang="less">
@import url(./index.less);
</style>
