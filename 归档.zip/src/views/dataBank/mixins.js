let that;
export const resourse = {
    data() {
        return {
            subject: JSON.parse(window.sessionStorage.commonList).subject,
            columns: [{
                    title: "名称",
                    dataIndex: "name",
                    scopedSlots: { customRender: "name" },
                    width: "420px",
                },
                // {
                //     title: "文件状态",
                //     dataIndex: "rangeName",
                //     key: "rangeName",
                //     scopedSlots: { customRender: "rangeName" },
                //     width: "150px",
                // },
                {
                    title: "学科",
                    dataIndex: "subject",
                    key: "subject",
                    scopedSlots: {
                        filterDropdown: 'filterDropdown',
                        filterIcon: 'filterIcon',
                        customRender: "subject"
                    },
                    width: "150px",
                },
                {
                    title: "大小",
                    dataIndex: "fileLength",
                    scopedSlots: { customRender: "fileLength" },
                    width: "100px",
                },
                {
                    title: "上传时间",
                    dataIndex: "createTime",
                    scopedSlots: { customRender: "createTime" },
                    key: "createTime",
                },
            ]
        }
    },
    filters: {
        getSubjectNameById(id) {
            let filterResults = that.subject.filter(item => item.id == id)
            return filterResults.length > 0 ? filterResults[0].name : ''
        }
    },
    beforeCreate() {
        that = this
    },
    methods: {

    },
}