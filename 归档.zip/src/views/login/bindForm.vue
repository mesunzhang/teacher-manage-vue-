<template>
  <div :class="{'layer':isLayer}">
  <a-form id="components-bind" :form="form" :class="{'layer':!!isLayer}">
    <div class="title" v-show="!isLayer">账号绑定</div>
    <div class="second-title" v-show="!isLayer">首次微信扫码登录，请先绑定智通云账号</div>
    <div class="second-title" v-show="isLayer">请补全信息，便于密码丢失找回</div>
    <a-form-item>
      <a-input
        v-decorator="[
          'phone',
          {
            rules: [
              {
                required: true,
                message: '请输入正确的手机号!',
                pattern: /^1[3456789]\d{9}$/,
              },
            ],
          },
        ]"
        @change="phoneChange"
        placeholder="手机号"
      >
      </a-input>
    </a-form-item>
    <a-form-item>
      <a-input
        v-decorator="[
          'phoneCode',
          {
            rules: [
              {
                required: true,
                message: '请输入正确的短信验证码!',
                pattern: /^\d{4,6}$/,
              },
            ],
          },
        ]"
        placeholder="短信验证码"
      >
      </a-input>
      <div class="getPhoneCode" @click="getCode">{{ codeWord }}</div>
    </a-form-item>
    <a-button type="primary" @click="handleSubmit" class="login-form-button">
      绑定
    </a-button>
  </a-form>
  </div>
</template>
<script>
import commonApi from "../../api/commonApi";
import $TN from "./tn_code";
export default {
  data() {
    return {
      codeWord: "获取验证码",
      isLayer:false
    };
  },
  props: ["unionId"],
  beforeCreate() {
    this.form = this.$form.createForm(this, { name: "normal_login" });
  },
  mounted:function(){
    this.isLayer = !!parent.layer
    if(this.isLayer){
      $TN.init();
      window.$TN = $TN;
    }
  },
  methods: {
    phoneChange(e){
			let reg =/^1[3456789]\d{9}$/
			if(reg.test(e.target.value)){
				document.querySelector('.getPhoneCode').style.color = '#2274c3'
			}
			else{
				document.querySelector('.getPhoneCode').style.color = ''
			}
		},
    getCode() {
      if(typeof this.codeWord === 'number') return
      this.form.validateFields(["phone"], (err, value) => {
        if(err) return
        commonApi
          .sendSms({
            mobile: value.phone,
            type: this.isLayer ? 3 : 4,
          })
          .then((res) => {
            if (!res) {
              this.codeWord = 60;
              let timer = setInterval(() => {
                this.codeWord = this.codeWord - 1;
                if (this.codeWord === 0) {
                  this.codeWord = "获取验证码";
                  clearInterval(timer);
                }
              }, 1000);
            } else if (res.code === 203) {
              $TN.show();
              document.getElementById("tncode_div").style.top = "45%";
              $TN.onsuccess( (token) => {
                commonApi
                  .sendSms({
                    mobile: value.phone,
                    type: this.isLayer ? 3 : 4,
                    token,
                  })
                  .then((res) => {
                    if (!res) {
                      this.codeWord = 60;
                      let timer = setInterval(() => {
                        this.codeWord = this.codeWord - 1;
                        if (this.codeWord === 0) {
                          this.codeWord = "获取验证码";
                          clearInterval(timer);
                        }
                      }, 1000);
                    }
                  });
              });
            }
          });
      });
    },
    handleSubmit() {
      this.form.validateFields((err, values) => {
        if (!err) {
          console.log(this.isLayer)
          if(this.isLayer){
            commonApi.bindPhone({
              mobile:values.phone,
              verifyCode:values.phoneCode,
            }).then(res=>{
              if(res.code === 200){
                this.$message.success('绑定成功!')
                setTimeout(()=>{
                  parent.location.reload()
                },3000)
              }
            })
          }
          else{
            commonApi
            .login({
              loginType: 4,
              account: values.phone,
              smsCode: values.phoneCode,
              wxInfo: {
                unionId: this.unionId,
              },
            })
            .then((res) => {
              if (res.code === 302) {
                  location.href = res.url;
                }
            });
          }
        }
      });
    },
  },
};
</script>
<style lang="less">
.layer{
  padding: 20px;
}
#components-bind {
  .title {
    font-weight: 600;
    font-size: 20px;
    color: rgba(0, 0, 0, 0.8);
  }
  .second-title {
    color: #333333;
    margin-top: 32px;
    margin-bottom: 10px;
  }
  input {
    height: 44px;
    background: #f5f5f5;
    border: 0;
    outline: none;
    border-radius: 4px;
    font-size: 16px;
    color: #333;
  }
  .ant-row{
    margin-bottom: 16px;
  }
  .ant-form-explain{
		font-size: 12px;
	}
  .getPhoneCode {
    cursor: pointer;
    font-size: 12px;
    color: #999999;
    position: absolute;
    right: 15px;
    top: -10px;
  }
  .login-form-button {
    width: 100%;
    background: #2274c3;
    height: 44px;
    font-size: 18px;
    margin-top: 10px;
  }
}
/*图片验证码*/
.tncode_div_bg {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 3000;
  /*background-color: rgba(0, 0, 0, 0.5);*/
  /*opacity: 0.3;*/
  /*filter: alpha(opacity=30);*/
  /*background-color: #000;*/
  *zoom: 1;
  display: none;
}

.tncode_div {
  box-sizing: border-box;
  padding: 20px 32px;
  display: none;
  background-color: #fff;
  z-index: 1000000;
  width: 356px;
  height: 250px;
  position: absolute;
  left: 50%;
  top: 55%;
  margin-top: -130px;
  margin-left: -178px;
  border-radius: 5px;
  filter: drop-shadow(0px 0px 8px rgba(0, 0, 0, 0.16));
}
.tncode_div:after {
  content: "";
  display: block;
  width: 10px;
  height: 10px;
  background: #fff;
  position: absolute;
  left: 175px;
  bottom: -5px;
  transform: rotate(45deg);
}

.tncode_div .tncode_header {
  font-size: 16px;
  color: #333333;
  letter-spacing: 0;
}
.tncode_div .tncode_canvas_bg {
  z-index: 0;
}

.tncode_div .tncode_canvas_mark {
  z-index: 10000;
}

.tncode_div canvas {
  position: absolute;
  left: 32px;
  top: 50px;
  border-radius: 4px;
}

.tncode_div .loading {
  border-radius: 4px;
  padding-top: 50px;
  position: absolute;
  left: 32px;
  top: 50px;
  background-color: #ccc;
  width: 292px;
  height: 120px;
  text-align: center;
  box-sizing: border-box;
}
.slide {
  position: absolute;
  top: 170px;
  width: 292px;
  height: 36px;
  margin: 3.39% 0;
  overflow: visible;
  border-radius: 4px;
  background-image: url("../../assets/img/slider-bg.png");
  background-size: cover;
}
.tools {
  float: right;
  height: 0px;
  position: relative;
}

.slide_block {
  width: 36px;
  height: 36px;
  position: absolute;
  border-radius: 4px;
  left: 0px;
  top: 0px;
  cursor: pointer;
  background-color: #3399ff;
}
.slide_block:after {
  display: block;
  content: "";
  width: 40px;
  height: 40px;
  position: relative;
  top: -2px;
  left: -2px;
  background-image: url("../../assets/img/slider.svg");
  background-size: contain;
  box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.1);
  background-repeat: no-repeat;
  background-position-x: right;
  background-position-y: center;
}
.slide.succ .slide_block:after {
  background-image: url("../../assets/img/slider_comp.svg");
}
.slide.succ .slide_block {
  border-radius: 4px;
  font-size: 14px;
  line-height: 36px;
  color: #fff;
  background-image: none;
  text-align: center;
}

.slide_block_text {
  background-position: 0px 12.9794%;
  height: 36px;
  line-height: 36px;
  position: absolute;
  left: 55px;
  top: 14px;
  margin: -4.62% 0 0 -2.31%;
  cursor: pointer;
  font-size: 14px;
  color: #666;
}
.slide.error .slide_block_text {
  color: #f00;
}

.tools .tncode_close {
  height: 16px;
  width: 16px;
  position: absolute;
  right: 5px;
  top: 5px;
  cursor: pointer;
  background-repeat: no-repeat;
  background-size: cover;
  background-image: url("../../assets/img/ic_close.png");
}

.tools .tncode_refresh {
  z-index: 30000;
  height: 16px;
  width: 16px;
  position: absolute;
  right: 10px;
  top: 40px;
  cursor: pointer;
  background-repeat: no-repeat;
  background-size: cover;
  background-image: url("../../assets/img/ic_reload.png");
}

.tools .tncode_tips {
  float: right;
}

.tools .tncode_tips a {
  text-decoration: none;
  font-size: 10px;
  color: rgb(136, 148, 157);
}
</style>