<template>
	<div class="main">
		<a-spin size="large" v-if="loading"/>
		<div class="main-content" v-show="!loading">
			<img class="logo" src="../../assets/img/logo_blue.png" />
			<div class="main-title">教师管理后台</div>
			<div class="tabs-box">
				<div
					class="tabs"
					:class="{ active: loginType === 'password' }"
					@click="loginType = 'password'"
				>
					<div class="word">账号登录</div>
				</div>
				<div
					class="tabs"
					:class="{ active: loginType === 'phone' }"
					@click="loginType = 'phone'"
				>
					<div class="word">短信登录</div>
				</div>
			</div>
			<a-form
				id="components-login"
				:form="form"
				@submit="handleSubmit"
				autocomplete="off"
			>
				<a-form-item v-show="loginType === 'password'">
					<a-input
						v-decorator="[
							'userName',
							{
								rules: [
									{
										required: true,
										message: '请输入平板账号!'
									}
								]
							}
						]"
						placeholder="平板账号"
					>
					</a-input>
				</a-form-item>
				<a-form-item v-show="loginType === 'password'">
					<a-input
						v-decorator="[
							'password',
							{
								rules: [
									{ required: true, message: '请输入密码!' }
								]
							}
						]"
						type="password"
						placeholder="密码"
					>
					</a-input>
				</a-form-item>
				<a-form-item v-show="loginType === 'phone'">
					<a-input
						v-decorator="[
							'phone',
							{
								rules: [
									{
										required: true,
										message: '请输入正确的手机号!',
										pattern: /^1[3456789]\d{9}$/
									}
								]
							}
						]"
						@change="phoneChange"
						placeholder="手机号"
					>
					</a-input>
				</a-form-item>
				<a-form-item v-show="loginType === 'phone'">
					<a-input
						v-decorator="[
							'phoneCode',
							{
								rules: [
									{
										required: true,
										message: '请输入正确的短信验证码!',
										pattern: /^\d{4,6}$/
									}
								]
							}
						]"
						placeholder="短信验证码"
					>
					</a-input>
					<div class="getPhoneCode" @click="getCode">
						{{ codeWord }}
					</div>
				</a-form-item>

				<a
					class="login-form-forgot"
					href="javascript:;"
					@click="toFollowPassword"
					v-show="loginType === 'password'"
				>
					忘记密码？
				</a>
				<a-button
					type="primary"
					html-type="submit"
					class="login-form-button"
				>
					登录
				</a-button>
				<!-- <div class="weixin" @click="getWxUrl">微信扫码登录</div> -->
			</a-form>
		</div>
		<div class="bottom-title">网站备案编号： 浙ICP备10024215号-6</div>
		<a-modal
			:visible="bindFormVisible"
			:footer="null"
			@cancel="bindFormVisible = false"
			width="400px"
			:centered="true"
		>
			<bindForm :unionId="unionId" />
		</a-modal>
	</div>
</template>

<script>
import $TN from "./tn_code";
import md5 from "md5";
import commonApi from "../../api/commonApi";
import bindForm from "./bindForm";
export default {
	data() {
		return {
			loading:false,
			loginType: "password",
			codeWord: "获取验证码",
			bindFormVisible: false,
			unionId: ""
		};
	},
	components: {
		bindForm
	},
	beforeCreate() {
		this.form = this.$form.createForm(this, { name: "normal_login" });
	},
	mounted() {
		$TN.init();
		window.$TN = $TN;
		let query = this.$route.query;
		if (query.appCode) {
			this.loading = true
			commonApi
				.login({
					wxInfo: query,
					loginType: 6
				})
				.then(res => {
					if (res.code === 300) {
						this.bindFormVisible = true;
						this.unionId = res.unionId;
						this.loading = false
					} else if (res.code === 302) {
						location.href = res.url;
					}
				});
		}
	},
	methods: {
		toFollowPassword() {
			this.$router.push({ path: "/followPassword" });
		},
		handleSubmit(e) {
			var self = this;
			//   const modal = this.$warning({
			//     content: `贵校已升级账号安全等级，教师管理后台已禁止使用账号登录，请使用短信登录或第三方登录。`,
			//   });
			e.preventDefault();
			let validateFieldsList =
				this.loginType === "password"
					? ["userName", "password"]
					: ["phone", "phoneCode"];
			this.form.validateFields(validateFieldsList, (err, values) => {
				if (!err) {
					console.log("Received values of form: ", values);
					if (self.loginType === "password") {
						$TN.show();
						document.getElementById("tncode_div").style.top = "";
						$TN.onsuccess(function(token) {
							let loginParam = {
								loginType: 1,
								account: values.userName,
								password: md5(values.password),
								imageCode: token
							};
							commonApi.login(loginParam).then(res => {
								if (res.code === 302) {
									location.href = res.url;
								}
								else{
									$TN.hide()
								}
							});
						});
					} else {
						commonApi
							.login({
								loginType: 4,
								account: values.phone,
								smsCode: values.phoneCode
							})
							.then(res => {
								if (res.code === 302) {
									location.href = res.url;
								}
							});
					}
				}
			});
		},
		phoneChange(e){
			let reg =/^1[3456789]\d{9}$/
			if(reg.test(e.target.value)){
				document.querySelector('.getPhoneCode').style.color = '#2274c3'
			}
			else{
				document.querySelector('.getPhoneCode').style.color = ''
			}
		},
		getCode() {
			if(typeof this.codeWord === 'number') return
			this.form.validateFields(["phone"], (err, value) => {
				if(err) return
				commonApi
					.sendSms({
						mobile: value.phone,
						type: 4
					})
					.then(res => {
						if (!res) {
							this.codeWord = 60;
							let timer = setInterval(() => {
								this.codeWord = this.codeWord - 1;
								if (this.codeWord === 0) {
									this.codeWord = "获取验证码";
									clearInterval(timer);
								}
							}, 1000);
						} else if (res.code === 203) {
							$TN.show();
							document.getElementById("tncode_div").style.top =
								"";
							$TN.onsuccess(token => {
								commonApi
									.sendSms({
										mobile: value.phone,
										type: 4,
										token
									})
									.then(res => {
										if (!res) {
											this.codeWord = 60;
											let timer = setInterval(() => {
												this.codeWord =
													this.codeWord - 1;
												if (this.codeWord === 0) {
													this.codeWord =
														"获取验证码";
													clearInterval(timer);
												}
											}, 1000);
										}
										else{
											$TN.hide()
										}
									});
							});
						}
					});
			});
		},
		getWxUrl() {
			commonApi.getWxCode().then(res => {
				location.href = res.data.qrCodeUrl;
			});
		}
	}
};
</script>

<style lang="less">
body {
	background: url("../../assets/img/bg_grey.png");
	.main{
		text-align: center;
		height: 100vh;
		.ant-spin{
			margin-top: 200px;
		}
	}
	.main-content {
		width: 500px;
		height: 532px;
		background: white;
		border: 1px solid #dbdbdb;
		position: absolute;
		left: 0;
		right: 0;
		top: 0;
		bottom: 0;
		margin: auto;
		text-align: center;
		padding: 46px 80px 0 80px;
		.logo{
			width: 160px;
		}
		.main-title {
			font-weight: 500;
			font-size: 24px;
			color: rgba(0, 0, 0, 0.8);
			margin: 16px 0 40px 0;
		}
		.tabs-box {
			.tabs {
				display: inline-block;
				width: 50%;
				font-size: 20px;
				color: #333333;
				cursor: pointer;
				.word {
					width: 80px;
					margin: 0 auto;
					padding-bottom: 12px;
					font-size: 16px;
				}
				&.active {
					.word {
						font-weight: 600;
						color: #2274c3;
						border-bottom: 3px solid #2274c3;
					}
				}
			}
		}
		#components-login {
			margin-top: 24px;
			.ant-form-explain {
				text-align: left;
			}
			.ant-row{
				margin-bottom: 16px;
			}
			.ant-form-explain{
				font-size: 12px;
			}
			input {
				height: 44px;
				background: #f5f5f5;
				border: 0;
				outline: none;
				border-radius: 4px;
				font-size: 16px;
				color: #333;
			}
			.getPhoneCode {
				cursor: pointer;
				font-size: 12px;
				color: #999999;
				position: absolute;
				right: 15px;
				top: -10px;
			}
			.login-form-forgot {
				float: right;
				font-size: 12px;
				color: #999999;
			}
			.login-form-button {
				width: 100%;
				background: #2274c3;
				height: 44px;
				font-size: 18px;
				margin-top: 10px;
			}
			.weixin {
				margin-top: 10px;
				font-size: 12px;
				color: #333333;
				text-align: center;
				cursor: pointer;
			}
		}
	}
	.bottom-title {
		color: #999999;
		position: fixed;
		bottom: 20px;
		text-align: center;
		width: 100%;
	}
}
</style>
