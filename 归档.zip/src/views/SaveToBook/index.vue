<template>
  <div class="main">
    <div v-show="!bookId">
      <a-select v-model="type" style="width: 200px" @change="onChange">
        <a-select-option value='10'> 校本书 </a-select-option>
        <a-select-option value='11'> 自建书 </a-select-option>
      </a-select>
      <a-input-search placeholder="搜索书名" style="width: 240px" v-model='searchText' @search="onSearch" />
    </div>
    <div class="list-box" v-show="!bookId">
        <div class="title">
          <span>书名</span>
          <span class="right">操作</span>
        </div>
        <div class="list-item" v-for="item of bookList" :key="item.bookId">
          <span>{{item.bookName}}</span>
          <span class="link" @click="selectBook(item.bookId)">选择</span>
        </div>
    </div>
    <div class="tree-box" v-show="bookId">
      <div class="tree-item">
        <a-tree :tree-data="leftTreeData" :replaceFields='replaceFields' @select='selectLeftTree'></a-tree>
      </div>
      <div class="tree-item">
          <Deep
							:folderList="folderList"
							@selectTree="selectTree"
							:selectedTree="selectedTree" />
      </div>
    </div>
  </div>
</template>

<script>
import commonApi from "../../api/commonApi";
import Deep from "@/components/powerControl/deep.vue";
export default {
  components:{Deep},
  data() {
    return {
        type:'11',
        page:1,
        size:10,
        searchText:'',
        bookList:[],
        bookId:'',
        replaceFields:{
          title:'name',
          key:'id'
        },
        leftTreeData:[],
        folderList: [],
        selectedTree: [],
        catalogId:''
    };
  },
  mounted() {
    this.getBooklist()
    window.init = this.init
    window.getSelectParam = this.getSelectParam
  },
  methods: {
    getBooklist(){
      commonApi.getSchoolResourceBooks({page:this.page,type:this.type,size:this.size,searchText:this.searchText}).then(res=>{
        this.bookList = res.data
      })
    },
    onChange(){
      this.getBooklist()
    },
    onSearch(){
      this.getBooklist()
    },
    selectBook(bookId){
      this.bookId = bookId;
      commonApi.getSchoolResourceBooksCatalogs({bookId}).then(res=>{
        this.leftTreeData = res
      })
    },
    selectLeftTree(key,event){
      this.catalogId = key[0]
      let hasChild = !!event.node.$children.length
      if(this.catalogId)
      commonApi.getSchoolFolderByBookIdAndCatalogId({bookId:this.bookId,catalogId:this.catalogId,filterResourceIds:[]}).then(res=>{
        if(!hasChild){
          this.folderList = [{
          id:0,
          name:'全部',
          children:res
        }]
        }
        else{
          this.folderList = []
        }
      })
    },
    selectTree(params){
      this.selectedTree = params
    },
    init(){
      this.searchText='';
      this.bookList=[];
      this.bookId='';
      this.leftTreeData=[];
      this.folderList=[];
      this.selectedTree=[];
      this.catalogId='';
      this.getBooklist()
    },
    getSelectParam(){
      return {
        targetBookId:this.bookId,
        targetCatalogId:this.catalogId,
        targetFolderId:this.selectedTree[0]
      }
    }
  },
};
</script>

<style lang="less">
.main {
  padding: 20px;
  .ant-input-search{
      margin-left: 20px;
  }
  .list-box{
      border: 1px solid #EEEEEE;
      margin-top: 20px;
      height: 280px;
      overflow: auto;
      .title{
          color: #B0B0B0;
          background: #f4f7fe;
          height: 40px;
          padding-left: 20px;
          padding-right: 32px;
          span{
            line-height: 40px;
          }
          .right{
            float: right;
          }
      }
      .list-item{
        border-bottom: 1px solid #EEEEEE;
        line-height: 40px;
        padding-left: 20px;
        padding-right: 32px;
        .link{
          color: #2274C3;
          float: right;
          cursor: pointer;
        }
      }
  }
  .tree-box{
        display: flex;
        .tree-item{
          flex: 1;
          height: 400px;
          border: 1px solid #EEEEEE;
          overflow: auto;
        }
      }
}
</style>
