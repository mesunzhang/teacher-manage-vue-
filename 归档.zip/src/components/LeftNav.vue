
<script>
    export {default} from './LeftNav.tsx'
</script>

<style scoped lang="less">
    
</style>