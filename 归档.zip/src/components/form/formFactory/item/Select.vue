<template>
    <a-form-item :label="op.label">
        <a-select style="min-width: 120px" :style="op.style"
                  v-decorator="[op.key, { rules: op.rules ,initialValue: init}]">
            <a-select-option v-for="(item, index) of op.options" :key="index" :value="item.key">
                {{item.value}}
            </a-select-option>
        </a-select>
    </a-form-item>
</template>
<script lang="ts">
  import { Component, Prop, Vue } from 'vue-property-decorator'
  import { Option } from '@/components/form/formFactory/modal'

  @Component
  export default class Select extends Vue {
    @Prop() op!: Option
    @Prop() init: any
  }
</script>

<style scoped lang="less">

</style>