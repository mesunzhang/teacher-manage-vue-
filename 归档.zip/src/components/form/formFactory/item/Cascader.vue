<template>
    <a-form-item :label="op.label">
        <a-cascader :options="op.options" :style="op.style" v-decorator="[op.key, { rules: op.rules ,initialValue: init}]" :placeholder="op.placeholder"/>
    </a-form-item>
</template>
<script lang="ts">
  import { Component, Prop, Vue } from 'vue-property-decorator'
  import { Option } from '@/components/form/formFactory/modal'

  @Component({
    components: {}
  })
  export default class Cascader extends Vue {
    @Prop() op!: Option
    @Prop() init: any
  }
</script>

<style scoped lang="less">

</style>