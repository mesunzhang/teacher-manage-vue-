import Input from '@/components/form/formFactory/item/Input.vue'
import Check from '@/components/form/formFactory/item/Check.vue'
import Select from '@/components/form/formFactory/item/Select.vue'
import Upload from '@/components/form/formFactory/item/Upload.vue'
import Radio from '@/components/form/formFactory/item/Radio.vue'
import Cascader from '@/components/form/formFactory/item/Cascader.vue'

const obj: any = {
  input: Input,
  check: Check,
  select: Select,
  upload: Upload,
  radio: Radio,
  cascader: Cascader,
}
export default obj