<template>
    <a-form-item :label="op.label">
         <a-radio-group v-decorator="[op.key, { rules: op.rules ,initialValue: init}]" :style="op.style">
            <a-radio v-for="(item,index) of op.options" :value="item.key" :key="index">
                {{item.value}}
            </a-radio>
        </a-radio-group>
    </a-form-item>
</template>
<script lang="ts">
  import { Component, Prop, Vue } from 'vue-property-decorator'
  import { Option } from '@/components/form/formFactory/modal'

  @Component
  export default class Radio extends Vue {
    @Prop() op!: Option
    @Prop() init: any
  }
</script>

<style scoped lang="less">

</style>