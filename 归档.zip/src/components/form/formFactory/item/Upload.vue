<template>
    <a-form-item :label="op.label">
        <UploadComponent :style="op.style" :op="op" v-decorator="[op.key, { rules: op.rules,initialValue: init }]"></UploadComponent>
    </a-form-item>
</template>
<script lang="ts">
  import { Component, Prop, Vue } from 'vue-property-decorator'
  import { Option } from '@/components/form/formFactory/modal'
  import UploadComponent from '@/components/form/formFactory/item/UploadComponent.vue'


  @Component({
    components: {
      UploadComponent
    }
  })
  export default class Upload extends Vue {
    @Prop() op!: Option
    @Prop() init: any
  }
</script>

<style scoped lang="less">

</style>

