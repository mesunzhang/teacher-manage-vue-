<template>
    <a-form-item :label="op.label">
        <a-checkbox v-if="op.checkAll" :indeterminate="checkList.length>0&&checkList.length<op.options.length"
                    :checked="checkList.length===op.options.length" @change="checkAllChange($event.target.checked)">{{op.checkAll}}</a-checkbox>
        <a-checkbox-group v-decorator="[op.key, { rules: op.rules ,initialValue: init}]" @change="checkAllStatus">
            <a-checkbox v-for="(item,index) of op.options" :value="item.key" :key="index">{{item.value}}</a-checkbox>
        </a-checkbox-group>
    </a-form-item>
</template>
<script lang="ts">
  import { Component, Prop, Vue } from 'vue-property-decorator'
  import { Option } from '@/components/form/formFactory/modal'

  @Component
  export default class Check extends Vue {
    @Prop() op!: Option
    @Prop() init: any
    checkList: any[] = []

    checkAllChange(status: boolean) {
      if (status) {
        (this.$parent as any).form.setFieldsValue({ [this.op.key]: this.op.options.map((i: any) => i.key) })
      } else {
        (this.$parent as any).form.setFieldsValue({ [this.op.key]: [] })
      }
      this.checkAllStatus()
    }

    async checkAllStatus() {
      await this.$nextTick()
      this.checkList = (this.$parent as any).form.getFieldValue(this.op.key) || []
    }
  }
</script>

<style lang="less">
  .ant-checkbox-wrapper{
      margin-right: 20px;
  }
</style>