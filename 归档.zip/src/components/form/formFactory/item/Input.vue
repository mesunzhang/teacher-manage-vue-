<template>
    <a-form-item :label="op.label">
        <a-input
                :placeholder="op.placeholder"
                v-decorator="[op.key, { rules: op.rules ,initialValue: init}]"
                :style="op.style"
                :type="op.inputType"
        />
    </a-form-item>
</template>
<script lang="ts">
  import { Component, Prop, Vue } from 'vue-property-decorator'
  import { Option } from '@/components/form/formFactory/modal'

  @Component
  export default class Input extends Vue {
    @Prop() op!: Option
    @Prop() init: any
  }
</script>

<style scoped lang="less">

</style>