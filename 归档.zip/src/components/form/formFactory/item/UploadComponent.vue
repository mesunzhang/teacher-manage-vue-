<template>
    <div>
        <a-upload
                :action="baseUrl+'/upload/icon'"
                list-type="picture-card"
                :file-list="fileList"
                @preview="handlePreview"
                @change="handleChange"
                :beforeUpload="beforeUpload"
        >
            <div v-if="fileList.length < (op.count||1)">
                <a-icon type="plus"/>
                <div class="ant-upload-text">
                    Upload
                </div>
            </div>
        </a-upload>
        <a-modal :visible="previewVisible" :footer="null" @cancel="handleCancel">
            <img alt="example" style="width: 100%" :src="previewImage"/>
        </a-modal>
    </div>
</template>
<script lang="ts">
  import { Component, Emit, Prop, Vue, Watch } from 'vue-property-decorator'
  import { getBase64 } from '@/util'


  @Component({
    components: {}
  })
  export default class UploadComponent extends Vue {
    @Prop() op: any
    @Prop() value: any
    previewVisible: boolean = false
    previewImage: string = ''
    fileList: any[] = []
    baseUrl: string = process.env.VUE_APP_BASE_API

    // 如果有外部传进来的值，刷新预览图片列表
    @Watch('value')
    getFileList() {
      let data = this.value || [];
      if(typeof data === 'string'){
        data = [data]
      }
      this.fileList = data.map((i: any, index: number) => {
        return {
          uid: '-' + (index + 1),
          name: 'image' + index + '.png',
          status: 'done',
          url: i
        }
      })
    }
    // 上传之前 超出大小就不上传
    beforeUpload(file: File) {
      if (file.size > 100 * 1024) {
        this.$message.error('图片大小超出100k')
        return false
      }
    }

    handleCancel() {
      this.previewVisible = false
    }
    // 预览图片
    async handlePreview(file: any) {
      if (!file.url && !file.preview) {
        file.preview = await getBase64(file.originFileObj)
      }
      this.previewImage = file.url || file.preview
      this.previewVisible = true
    }
    // 显示的图片有变化   每次上传图片，该方法会多次调用 status
    handleChange({ fileList, file }: any) {
      // 过滤掉 没有上传状态的图片， 例: 图片过大 上传取消
      this.fileList = fileList.filter((i: any) => i.status)
      // 当列表中 所有图片的status = done  才算上传成功  这时通知外界表单变化
      if (this.fileList.every((i: any) => {
        return i.status === 'done'
      })) {
        this.uploadSuccess(this.fileList.map((i: any) => {
          return i.response.msg
        }))
      }
    }

    @Emit('change')
    uploadSuccess(imgs: string[]) {
      return imgs
    }
  }
</script>

<style scoped lang="less">

</style>