export interface Option {
  type: string;
  key: string;
  init?: any;
  label?: string;
  rules?: any[];
  placeholder?: string;
  inputType?: string;
  options?: any;
  checkAll?: any
  count?: number;
  style?: any;
  relyOn?: (value: any) => boolean
}

export interface Modal {
  show: (callback?: Function, init?: any) => void
}
