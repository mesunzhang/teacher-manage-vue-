import { Component, Prop, Vue, Ref, Emit } from 'vue-property-decorator'
import { CreateElement } from 'vue'
import { Option } from '@/components/form/formFactory/modal'
import ItemList from '@/components/form/formFactory/item'

@Component({
  props: {
    config: {
      type: Object,
      default() {
        return {}
      }
    },
    options: {
      type: Array,
      default() {
        return []
      }
    }
  }
})
export default class FormIndex extends Vue {
  @Prop() options!: Option[]
  @Prop() config!: any

  get _config() {
    const obj = {
      'background-color': '#fff',
      labelCol: { span: 4 },
      wrapperCol: { span: 8 },
      confirmText: '确定',
      cancelText: '取消',
      confirmShow: true,
      cancelShow: true,
      ...this.config
    }
    if (obj.layout === 'inline') {
      obj.labelCol = {}
      obj.wrapperCol = {}
    }
    return obj
  }

  form: any
  initValue: any = {}

  setFormValue(init: any) {
    this.initValue = init || {}
    // 设置值的时候 将有relyOn的选项和表单外的排除掉，以免报警告 虽然能运行
    this.form.setFieldsValue(Object.assign({}, ...this.options.filter((i: Option) => !i.relyOn).map((i: Option) => {
      return {
        [i.key]: init[i.key]
      }
    })))
  }


  beforeCreate() {
    this.form = this.$form.createForm(this, { name: 'normal_forms' })
  }

  @Emit('submit')
  async onSubmit(e: any) {
    e.preventDefault()
    return await this.form.validateFields()
  }

  @Emit('cancel')
  onCancel() {

  }


  render(h: CreateElement) {
    const items = []
    for (let op of this.options) {
      if (op.relyOn && !op.relyOn(this.form.getFieldsValue())) {
        continue
      }
      const type: any = ItemList[op.type]
      if (!type) {
        items.push(<div>type not found</div>)
      } else {
        items.push(h(type, {
          props: {
            op, init: this.initValue[op.key]
          }
        }))
      }

    }

    // const items = this.options.map((op: Option) => {
    //   const type: any = ItemList[op.type]
    //   if (!type) {
    //     return <div>type not found</div>
    //   }
    //   return h(type, {
    //     props: {
    //       op
    //     }
    //   })
    // })

    return (
      <div style={this._config}>
        <a-form form={this.form} label-col={this._config.labelCol}
                layout={this._config.layout}
                wrapper-col={this._config.wrapperCol} onSubmit={this.onSubmit}>
          {items}
          <a-form-item style={{ display: this._config.layout === 'inline' ? 'block' : '' }}
                       wrapper-col={this._config.layout === 'inline' ? {} : {
                         span: this._config.wrapperCol.span,
                         offset: this._config.labelCol.span
                       }}>
            <a-config-provider auto-insert-space-in-button={false}>
              {this._config.confirmShow && <a-button class="btn" type="primary" html-type="submit">
                {this._config.confirmText}
              </a-button>}
              {this._config.cancelShow && <a-button class="btn" style="margin-left: 10px;" onClick={this.onCancel}>
                {this._config.cancelText}
              </a-button>}
            </a-config-provider>
          </a-form-item>
        </a-form>
      </div>
    )
  }
}