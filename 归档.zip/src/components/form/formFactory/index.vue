<script>
  export { default } from './index.tsx';
</script>

<style scoped lang="less">
    header{
        line-height: 56px;
        height: 56px;
        font-size: 16px;
        color: rgba(0,0,0,0.85);
        padding-left: 24px;
        border-bottom: 1px solid rgba(0,0,0,0.06);
    }
    .btn{
        letter-spacing: 0;
    }
</style>
<style>
    .ant-form-item{
        margin-bottom: 14px;
    }
</style>