<template>
  <div class="page-form">
    <FormIndex :options="options" :config="{layout:'inline', confirmText: '搜索',cancelShow: false}"  @submit="submit"></FormIndex>
<!--    <a-form layout="inline"  @submit="submit">-->
<!--      <a-form-item label="部门">-->
<!--        <a-cascader :options="options" change-on-select @change="onChange" />-->
<!--      </a-form-item>-->
<!--      <a-form-item label="姓名">-->
<!--        <a-input-search placeholder="input search text" style="width: 200px" @search="onSearch" />-->
<!--      </a-form-item>-->
<!--    </a-form>-->

<!--    <div class="department">-->
<!--      <span>部门：</span>-->
<!--      <a-cascader :options="options" change-on-select @change="onChange" />-->
<!--    </div>-->
<!--    <div class="name">-->
<!--      <span>姓名：</span>-->
<!--      <a-input-search placeholder="input search text" style="width: 200px" @search="onSearch" />-->
<!--    </div>-->

  </div>
</template>

<script lang="ts">
  import {Component, Emit, Vue} from 'vue-property-decorator'
  import FormIndex from './formFactory/index.vue'
  import { Option } from '@/components/form/formFactory/modal'

    @Component({
        components: {FormIndex}
    })
    export default class searchUserForm extends Vue{
        options: Option[] = [
          {
            label: '部门',
            type: 'cascader',
            key: 'department',
            style:{
              minWidth: '300px'
            },
            options:[
              {
                value: 'zhejiang',
                label: 'Zhejiang',
                children: [
                  {
                    value: 'hangzhou',
                    label: 'Hangzhou',
                    children: [
                      {
                        value: 'xihu',
                        label: 'West Lake',
                      },
                    ],
                  },
                ],
              },
              {
                value: 'jiangsu',
                label: 'Jiangsu',
                children: [
                  {
                    value: 'nanjing',
                    label: 'Nanjing',
                    children: [
                      {
                        value: 'zhonghuamen',
                        label: 'Zhong Hua Men',
                      },
                    ],
                  },
                ],
              }
            ]
          },
          {
            label: '姓名',
            type: 'input',
            key: 'name',
            style:{
              minWidth: '300px'
            },
            options:[]
          }
        ]

      @Emit('search')

      onChange(value:any){
        console.log(value)
      }
      submit(e: any){
        return e;
      }
    }
</script>

<style scoped lang="less">
  .page-form {
    padding: 24px 0 1px;
    background-color: #fff;
  }
</style>