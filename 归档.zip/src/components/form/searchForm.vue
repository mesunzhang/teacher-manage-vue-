<template>
    <div class="page-form">
        <FormIndex :options="options" :config="{ confirmText: '搜索',cancelShow: false,layout: 'inline'}"
                   @submit="submit"></FormIndex>
    </div>
</template>
<script lang="ts">
  import { Component, Emit, Vue } from 'vue-property-decorator'
  import FormIndex from './formFactory/index.vue'
  import { Option } from '@/components/form/formFactory/modal'

  @Component({
    components: { FormIndex }
  })
  export default class SearchForm extends Vue {
    options: Option[] = [
      {
        label: '状态',
        type: 'check',
        key: 'status',
        checkAll: '全部',
        options: [
          {
            key: 1,
            value: '启用'
          },
          {
            key: 2,
            value: '禁用'
          }
        ]
      }
    ]

    @Emit('search')
    submit(e: any) {
      return e
    }
  }
</script>

<style scoped lang="less">
    .page-form {
        padding: 24px 0 1px;
        background-color: #fff;
    }
</style>