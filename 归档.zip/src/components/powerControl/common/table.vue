<template>
	<div></div>
</template>

<script>
import mixin from "../mixins/data.vue";
export default {
	data() {
		return {};
	},
	mounted() {
		this.getUserResourceList();
	},
	methods: {},
	mixins: [mixin]
};
</script>

<style></style>
