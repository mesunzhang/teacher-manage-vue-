<script>
import PowerApi from "@/api/powerControl";
import commonApi from "@/api/commonApi";
import $ from "jquery";
const columns = [
	{
		title: "名称",
		dataIndex: "name",
		scopedSlots: { customRender: "name" },
		width: "350px"
	},
	{
		title: "文件状态",
		dataIndex: "rangeName",
		key: "rangeName",
		scopedSlots: { customRender: "rangeName" },
		width: "150px"
	},
	{
		title: "大小",
		dataIndex: "fileLength",
		scopedSlots: { customRender: "fileLength" },
		width: "100px"
	},
	{
		title: "上传时间",
		dataIndex: "createTime",
		scopedSlots: { customRender: "createTime" },
		key: "createTime"
	}
];
export default {
	data() {
		return {
			columns,
			classList: [],
			tableData: [],
			pagination: {
				current: 1,
				total: 0,
				pageSize: 20,
				showSizeChanger: true,
				itemRender: this.itemRender
			},
			formData: {
				page: 1,
				size: 20,
				classId: "",
				subjectId: "",
				gradeId: ""
			},
			selectedTree: [],
			//选中的成员列表
			selectedRowKeys: []
		};
	},
	mounted() {},
	methods: {
		openFile(id) {
			$.ajax({
				type: "post",
				url: "/resource/Resource/getFileTempUrl",
				data: JSON.stringify({
					resourceIdList: [id],
					requestType: "view"
				}),
				success: function(res) {
					if (res.data[0].resourceType === 9) {
						aliplay(res.data[0].resourceId);
					} else {
						window.open(
							"https://play.yunzuoye.net/play?type=" +
								res.data[0].resourceType +
								"&src=" +
								res.data[0].fileUrl
						);
					}
				}
			});

			function aliplay(videoId) {
				var send = {
					videoId: videoId,
					mKey: "teacherZtktVideo"
				};
				if (navigator.userAgent.match(/Android [4-5]/i)) {
					$.ajax({
						url: "/common/aly/getPlayInfo",
						type: "post",
						data: JSON.stringify(send),
						success: function(res) {
							if (res.data.code == "404") {
								this.$message.error("视频出错");
							} else if (res.data.code == "403") {
								this.$message.error(
									"视频正在转码中，请稍后再点击"
								);
							} else {
								window.open(
									"/mobile/resource/play?src=" +
										res.data.PlayInfoList.PlayInfo[0]
											.PlayURL +
										"&title="
								);
							}
						}
					});
				} else {
					$.ajax({
						url: "/common/aly/getPlayAuth",
						type: "post",
						data: JSON.stringify(send),
						success: function(res) {
							if (res.data.code == "404") {
								this.$message.error("视频出错");
							} else if (res.data.code == "403") {
								this.$message.error(
									"视频正在转码中，请稍后再点击"
								);
							} else {
								window.open(
									"/mobile/resource/aliplayerVideo?vid=" +
										send.videoId +
										"&playauth=" +
										res.data.PlayAuth +
										"&title="
								);
							}
						}
					});
				}
			}
		},
		itemRender(current, type, originalElement) {
			// debugger;
			if (type === "prev") {
				return `上一页`;
			} else if (type === "next") {
				return `下一页`;
			}
			return originalElement;
		},
		// 进入文件夹
		selectFolder(record) {
			this.formData.fileId = record.id;
			this.selectedTree = [record.id];
			// 初始化复选框状态
			this.selectChange([], []);
			this.getUserResourceList();
		},
		selectTree(params) {
			this.formData.fileId = params[0];
			this.formData.page = 1;
			this.pagination.current = 1;
			this.selectedTree = params;
			// 初始化复选框状态
			this.selectChange([], []);
			if (!this.showTree) {
				this.getUserResourceList();
			}

			if (parent && parent.getFilesList) {
				parent.getFilesList(this.formData.fileId);
			}
		},
		// 获取左侧目录树结构
		getFolder() {
			PowerApi.getFolder().then(res => {
				res.data = [{ id: "", name: "我的资料库", children: res.data }];
				this.folderList = res.data;
			});
		},
		// 改变页码
		onChange(selectedRowKeys) {
			this.pagination = selectedRowKeys;
			this.formData.page = this.pagination.current;
			this.formData.size = this.pagination.pageSize;
			// 初始化复选框状态
			this.selectChange([], []);
			this.getUserResourceList();
		},
		returnSrc(item) {
			switch (item.resourceType) {
				case 1:
					return require("../../../static/common/ic_video.png");
				case 2:
					return require("../../../static/common/ic_yinpin.png");
				case 3:
					return require("../../../static/common/ic_weike.png");
				case 4:
					return require("../../../static/common/ic_weike.png");
				case 5:
					return require("../../../static/common/ic_ppt.png");
				case 6:
					return require("../../../static/common/ic_word.png");
				case 7:
					return require("../../../static/common/ic_img.png");
				case 8:
					return require("../../../static/common/ic_pdf.png");
				case 9:
					return require("../../../static/common/ic_video.png");
				case 10:
					return require("../../../static/common/ic_wenjianjia.png");
			}
		},
		tableHandle(record, index) {
			return {
				on: {
					click: () => {
						this.checkSelector(index);
					}
				}
			};
		},
		// 获取右侧资料列表
		getUserResourceList() {
			PowerApi.getUserResourceList(this.formData).then(res => {
				this.tableData = res.data.list;
				// 全部班级状态下文件状态字段的展示
				if (false) {
					TODO;
					if (this.formData.classId == " ") {
						let arr = ["", "全公开", "部分公开", "未公开"];
						// 因为默认添加了一个全部，所以需要总长度 - 1
						let totalLength = this.classList.length - 1;
						this.tableData.forEach(item => {
							// 全公开
							if (
								item.classPublicSettingList.length ==
								totalLength
							) {
								item.rangeName = arr[1];
								// 未公开
							} else if (
								item.classPublicSettingList.length == 0
							) {
								item.rangeName = arr[3];
								// 部分公开
							} else {
								item.rangeName = arr[2];
							}
						});
						// 单个班级状态下文件状态字段的展示
					} else {
						this.tableData.forEach(item => {
							let index = item.classPublicSettingList.findIndex(
								findItem => {
									return (
										findItem.classId ==
										this.formData.classId
									);
								}
							);
							if (index != -1) {
								item.rangeName =
									item.classPublicSettingList[
										index
									].publicSettingText;
							} else {
								item.rangeName = "未公开";
							}
							// item.rangeName = arr[item.publicRange];
						});
					}
				}
				this.pagination.total = res.data.totalCount;
			});
		},
		// 改变复选框
		selectChange(indexList, data) {
			this.selectedRowKeys = indexList;
			if (indexList.length == this.tableData.length) {
				this.settingFormData.selectAll = true;
			} else {
				this.settingFormData.selectAll = false;
			}
			// 存储 => 关闭的目录id
			this.settingFormData.fileId = this.selectedTree[0] || " ";
			// 表格不存在数据 || 选中的数据和实际全部的数据不等
			// 传参
			if (
				data.length !== this.tableData.length ||
				this.tableData.length == 0
			) {
				this.settingFormData.resourceList = data.map(item => {
					return { resourceId: item.id, isdir: item.isdir };
				});
			} else {
				// 全选的话，不需要传参(resourceList)
				delete this.settingFormData.resourceList;
			}
		},
		checkSelector(index) {
			let findIndex = this.selectedRowKeys.findIndex(_ => index == _);
			if (findIndex == -1) {
				this.selectedRowKeys.push(index);
				this.selectedRowKeys = [...new Set(this.selectedRowKeys)];
			} else {
				this.selectedRowKeys.splice(findIndex, 1);
			}
		}
	}
};
</script>

<style></style>
