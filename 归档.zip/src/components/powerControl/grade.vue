<template>
	<div class="powerContainer_main">
		<div class="fileContainer">
			<div class="fileContainer_main">
				<div style="width: 100%; display: flex; height: 48px">
					<div class="subject">
						<a-dropdown :trigger="['click']">
							<div class="subject_container">
								<span>{{ selectSubject }}</span>
								<a-icon type="down" />
							</div>
							<a-menu slot="overlay" v-model="selectSubjectValue">
								<a-menu-item
									v-for="item in subject"
									:key="item.id"
									@click="checkSubjectItem"
								>
									{{ item.name }}
								</a-menu-item>
							</a-menu>
						</a-dropdown>
					</div>
					<a-menu
						mode="horizontal"
						style="padding: 0 20px; flex: 1; height: 48px"
						v-model="selectGradesValue"
					>
						<a-menu-item
							v-for="item in grades"
							:key="item.id"
							@click="checkGradesItem"
						>
							{{ item.name }}
						</a-menu-item>
					</a-menu>
				</div>
				<div style="display: flex">
					<div class="tree">
						<Deep
							:folderList="folderList"
							@selectTree="selectTree"
							:selectedTree="selectedTree"
							v-if="folderList.length > 0"
						></Deep>
					</div>

					<div class="tab">
						<div class="button-group">
							<div class="button_left">
								<a-button
									class="button"
									@click="openShareObject"
									>共享库设置</a-button
								>
								<a-button class="button" @click="openShare"
									>转存</a-button
								>
								<a-button class="button" @click="openShare">
									取消共享
								</a-button>
							</div>
							<div class="button_right">
								<a-checkbox @change="selectMyShare">
									只看我共享的
								</a-checkbox>
								<a-input
									placeholder="搜索文件名/老师"
									class="input"
								>
									<img
										slot="prefix"
										src="@/assets/img/dataBank/ic_input_search.png"
										alt=""
									/>
								</a-input>
							</div>
						</div>
						<div>
							<Table></Table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- 共享库设置 -->
		<share-object
			v-model="showShareObject"
			@change="changeShareObjectStatus"
		></share-object>
		<!-- 取消共享 -->
		<share v-model="showShare" @change="changeShareStatus"></share>
	</div>
</template>

<script>
import Deep from "@/components/powerControl/deep.vue";
import mixin from "./mixins/data.vue";
import PowerApi from "@/api/powerControl";
import commonApi from "@/api/commonApi";
import shareObject from "@/views/powerControl/components/sharelib-config";
import share from "@/components/public/share/index.vue";

export default {
	data() {
		return {
			showShareObject: false,
			showShare: false,
			selectSubject: "",
			selectSubjectValue: [],
			selectGradesValue: [],
			grades: [],
			subject: [],
			folderList: []
		};
	},
	mounted() {
		this.getBaseConfig();
	},
	methods: {
		// 选中只看我共享的复选框
		selectMyShare(event) {
			let checked = event.target.checked;
		},
		checkSubjectItem(item, key, keyPath) {
			this.selectSubjectValue = [item.key];
			let findObject = this.subject.find(subjectItem => {
				return subjectItem.id == item.key;
			});
			this.selectSubject = findObject.name;
		},
		checkGradesItem(item) {
			this.selectGradesValue = [item.key];
		},
		async getBaseConfig() {
			this.getSubject();
			this.getGrades();
		},
		getGrades() {
			PowerApi.getBaseConfig({ name: "grades" }).then(res => {
				this.grades = res.grades;
				this.selectGradesValue = [res.grades[0].id];
			});
		},
		getSubject() {
			PowerApi.getBaseConfig({ name: "subject" }).then(res => {
				this.subject = res.subject;
				this.selectSubjectValue = [res.subject[0].id];
				this.selectSubject = res.subject[0].name;
			});
		},
		// 打开共享库设置
		openShareObject() {
			this.showShareObject = true;
		},
		// 改变共享库设置弹出框显示状态
		changeShareObjectStatus(status) {
			this.showShareObject = status;
		},
		// 打开取消共享
		openShare() {
			this.showShare = true;
		},
		// 改变取消共享弹出框显示状态
		changeShareStatus(status) {
			this.showShare = status;
		}
	},
	mixins: [mixin],
	watch: {
		selectSubjectValue(newval) {
			console.log(newval);
		}
	},
	components: {
		Deep,
		Table,
		shareObject,
		share
	}
};
</script>

<style></style>
