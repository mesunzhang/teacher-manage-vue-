<script lang="jsx">
export default {
	name: "deep",
	props: {
		folderList: {
			default() {
				return [];
			},
			type: Array
    },
    selectedTree:{
      default(){
        return []
      },
      type:Array
    },

  },
  render(h){
    const deepChapter = folderList => {

      return folderList.map(item => {
         if(item.id!=''){
          this.folderLevel[item.id]=item.level;
        }
        if (item.children) {
          return (
              <a-tree-node
            key={item.id}
            title={item.name}
            style={this.style}
            >
           <span
                slot="icon"
                style="height:100%;"
              >
<img  src={require('@/static/common/ic_wenjianjia.png')}
                style="width:16px;height:16px" />
              </span>
              {deepChapter(item.children)}
            </a-tree-node>
            )
        } else {
          return (
              <a-tree-node
            key={item.id}
            title={item.name}
            style={this.style}
            >
              <span
                slot="icon"
                style="height:100%;"
              >
<img  src={require('@/static/common/ic_wenjianjia.png')}
                style="width:16px;height:16px" />
              </span>
            </a-tree-node>
          )
        }
      });
     };
    return (
      <a-directory-tree
              defaultExpandedKeys={[""]}
              vOn:select={this.selectTree}
              vOn:expand={this.modifyHeight}
							show-icon={true}
              selectedKeys={this.selectedTree}
              checkedKeys={this.selectedTree}
						>
      {deepChapter(this.folderList)}
      </a-directory-tree>
    )
  },
	data() {
		return {
      folderLevel:{},
	    style:{

      }
		};
	},
	mounted() {
    this.modifyHeight()

  },
  updated(){

  },
	methods: {
    getStyle(obj,attr){
      if(obj.currentStyle){
        return obj.currentStyle[attr]
      }else{
        return getComputedStyle(obj,false)[attr]
      }
    },
     // 每次折叠页面时，dom将会重新渲染，这会导致代码修改的属性会覆盖。故在此添加此方法
    modifyHeight(){
      this.$nextTick(()=>{
        let unhandleArray = document.getElementsByClassName("ant-tree-node-content-wrapper")
        for(let item of unhandleArray){
          let height = parseInt(this.getStyle(item,"height"))
          if(height>32){
            item.setAttribute("twoLine","1")
          }
        }
       })
    },
    	selectTree(params) {
        if(parent){
          parent.$(parent.window).scrollTop(0)
        }
        this.$emit("selectTree",params)
			// this.formData.fileId = params[0];
			// this.formData.page = 1;
			// this.pagination.current = 1;
			// this.selectedTree = params;
			// this.getUserResourceList();
		},
  }
};
</script>

<style lang="less">
.ant-tree-title {
	max-width: 150px;
	overflow: hidden;
	text-overflow: ellipsis;
	-webkit-line-clamp: 2;
	max-height: 40px;
	line-height: 20px;
	height: auto;
	white-space: normal !important;
	display: -webkit-inline-box;
	-webkit-box-orient: vertical;
	vertical-align: middle;
	word-wrap: break-word;
	font-size: 14px;
}
.ant-tree li {
	padding: 0;
}
.ant-tree li .ant-tree-node-content-wrapper {
	transition: 0s all !important;
	height: auto !important;
	min-height: 32px;
	display: inline-flex;
	align-items: center;
}
.ant-tree.ant-tree-directory > li span.ant-tree-switcher,
.ant-tree.ant-tree-directory .ant-tree-child-tree > li span.ant-tree-switcher {
	margin-top: 4px;
}
.ant-tree-node-content-wrapper-normal {
	height: auto !important;
	min-height: 32px;
	vertical-align: middle;
}
.ant-tree.ant-tree-directory
	> li
	span.ant-tree-node-content-wrapper.ant-tree-node-selected,
.ant-tree.ant-tree-directory
	.ant-tree-child-tree
	> li
	span.ant-tree-node-content-wrapper.ant-tree-node-selected {
	color: #2274c3;
}
.ant-tree.ant-tree-directory
	> li.ant-tree-treenode-selected
	> span.ant-tree-switcher,
.ant-tree.ant-tree-directory
	.ant-tree-child-tree
	> li.ant-tree-treenode-selected
	> span.ant-tree-switcher {
	color: #2274c3;
}

.ant-tree.ant-tree-directory
	> li.ant-tree-treenode-selected
	> span.ant-tree-node-content-wrapper::before,
.ant-tree.ant-tree-directory
	.ant-tree-child-tree
	> li.ant-tree-treenode-selected
	> span.ant-tree-node-content-wrapper::before {
	background: #c6e5f5;
	border-left: 2px solid#2274C3;
}
[twoLine]::before {
	height: 40px !important;
}
[twoLine] .ant-tree-iconEle {
	margin-bottom: 20px !important;
}
.ant-tree.ant-tree-directory > li span.ant-tree-node-content-wrapper::before,
.ant-tree.ant-tree-directory
	.ant-tree-child-tree
	> li
	span.ant-tree-node-content-wrapper::before {
	min-height: 32px;
}
.ant-tree-iconEle {
	height: 20px !important;
	line-height: 20px !important;
	width: 20px !important;
	margin-right: 5px !important;
	vertical-align: middle !important;
}
.ant-tree-child-tree > li:first-child {
	padding-top: 0px !important;
}
.tree {
	overflow-y: auto;
	min-height: 895px;
	max-height: 895px;
}
</style>
