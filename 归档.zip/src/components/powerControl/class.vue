<template>
	<div class="powerContainer_main">
		<div class="fileContainer">
			<div class="fileContainer_main">
				<div style="width:100%;">
					<a-menu
						v-model="selectedClass"
						mode="horizontal"
						style="padding:0 20px;"
					>
						<a-menu-item
							v-for="item in classList"
							:key="item.classId"
						>
							{{ item.className }}
						</a-menu-item>
					</a-menu>
				</div>
				<div style="display:flex;">
					<div class="tree">
						<Deep
							:folderList="folderList"
							@selectTree="selectTree"
							:selectedTree="selectedTree"
							v-if="folderList.length > 0"
						></Deep>
					</div>

					<div class="tab">
						<div class="button-group">
							<div class="button_left">
								<a-button
									class="button"
									@click="openSetting('close')"
									>关闭</a-button
								>
								<a-button
									class="button"
									@click="openSetting('open')"
									>公开</a-button
								>
								<a-button class="button"
									><a
										@click="
											$router.push({
												name: 'powerControlHistory'
											})
										"
										>操作记录</a
									></a-button
								>
							</div>
						</div>
						<div>
							<a-table
								:columns="columns"
								:data-source="tableData"
								:customRow="tableHandle"
								:row-selection="{
									onChange: selectChange,
									selectedRowKeys: selectedRowKeys
								}"
								:pagination="pagination"
								@change="onChange"
							>
								<template slot="name" slot-scope="text, record">
									<div
										style="width:100%;max-width:370px;cursor:pointer"
									>
										<img
											src="@/static/common/ic_wenjianjia.png"
											v-if="record.isdir == 2"
											alt=""
											style="width: 16px; height: 16px; margin-right: 8px"
											@click.stop="selectFolder(record)"
										/>
										<img
											v-else
											:src="returnSrc(record)"
											alt=""
											style="width: 16px; height: 16px; margin-right: 8px"
											@click.stop="openFile(record.id)"
										/>
										<span
											class="tableSubName"
											@click.stop="
												record.isdir == 2
													? selectFolder(record)
													: openFile(record.id)
											"
											>{{ text }}</span
										>
									</div>
								</template>

								<template
									slot="fileLength"
									slot-scope="file, record"
								>
									<div v-if="record.isdir == 2">
										--
									</div>
									<div v-else>
										{{ file }}
									</div>
								</template>
								<template
									slot="rangeName"
									slot-scope="rangeName"
								>
									<div>
										{{ rangeName }}
									</div>
								</template>

								<template slot="createTime" slot-scope="time">
									<div>
										{{ time }}
									</div>
								</template>
							</a-table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<settingModal
			:type="openType"
			v-model="openVisible"
			:openClassList="openClassList"
			:selectedTabsValue="selectedTabsValue"
			@change="setting"
		></settingModal>
	</div>
</template>

<script>
import SettingModal from "@/components/public/settingModal/index.vue";
import Deep from "@/components/powerControl/deep.vue";
import mixin from "./mixins/data.vue";
import PowerApi from "@/api/powerControl";
import commonApi from "@/api/commonApi";
export default {
	props: { folderList: { default: [], type: Array } },
	data() {
		return {
			openType: "",
			openVisible: false,
			openClassList: [],
			// 班级公开下面的menu选定值
			selectedClass: [" "],
			selectedTabsValue: " ",
			// 公开 || 关闭
			settingFormData: {
				resourceList: [],
				selectAll: false
			},
			showSettingModal: true
		};
	},
	mounted() {
		this.getClassList();
		this.getUserResourceList();
	},
	methods: {
		selectMenu(item) {
			this.selectName = item.name;
		},
		// 获取班级列表接口
		getClassList() {
			PowerApi.getClassList().then(res => {
				res.data.unshift({
					className: "全部",
					classId: " ",
					classType: -1
				});
				this.classList = res.data;
				// 关闭 公开 弹出框 班级列表
				this.openClassList = this.classList.map(item => {
					// debugger
					return {
						label: item.className,
						value: item.classId,
						classType: item.classType
					};
				});
			});
		},
		// 公开 或者 关闭 弹出框 确定 操作
		// type==open 公开 type == close 关闭
		setting(params) {
			if (params == false) {
				this.openVisible = false;
				return;
			}

			let formData = { ...this.settingFormData, ...params };
			if (params.type == "open") {
				commonApi.setAuth(formData).then(res => {
					if (res.code != 200) {
						return;
					}
					this.openVisible = false;
					this.getUserResourceList();
				});
			} else {
				powerControl.batchClose(formData).then(res => {
					this.openVisible = false;
					this.getUserResourceList();
				});
			}
		},
		// 打开关闭||公开弹出框
		openSetting(type) {
			// 分两种情况。
			// 1 全选 存在fileId 不存在 resourceList
			// 2 单选 不存在fileId 存在 resourceList
			if (
				(!this.settingFormData.resourceList &&
					!this.settingFormData.fileId) ||
				(this.settingFormData.resourceList &&
					this.settingFormData.resourceList.length == 0)
			) {
				// debugger
				return this.$message.error("请先选择文件");
			}
			this.openType = type;
			this.openVisible = true;
		}
	},
	components: {
		Deep,
		SettingModal
	},
	mixins: [mixin]
};
</script>
