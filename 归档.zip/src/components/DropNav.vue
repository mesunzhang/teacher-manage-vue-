<template>
    <a-drawer
            :wrap-style="{ position: 'absolute' }"
            :get-container="false"
            title
            placement="top"
            :closable="true"
            :visible="visible"
            class="dropNav"
            @close="onClose"
    >
        <ul class="dropNav_list">
            <li v-for="(item,index) in navList" :key="index" class="dropNav_list_single">
                <h2 class="dropNav_list_name">
                    {{item.name}}
                    <!-- {{item.name}} -->
                </h2>
                <ul class="dropNav_childrenList">
                    <li v-for="(ite,index) in item.children" :key="index" class="dropNav_childrenList_single">
                        <!-- 导航链接 -->
                        <a :href="ite.url" class="dropNav_childrenList_link">
                            {{ite.name}}
                            <!-- {{ite.name}} -->
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </a-drawer>
</template>
<script lang="ts">
  import { Component, Vue, Prop } from 'vue-property-decorator'
  import { getQuickList } from '@/httpService/global.service'

  @Component({
    components: {}
  })
  export default class DropNav extends Vue {
    navList: any = []
    //  data
    visible: boolean = false

    //  methods
    onClose() {
      this.visible = false
    }

    created() {
      this.getList()
    }

    async getList() {
      this.navList = await getQuickList()
    }
  }
</script>
<style lang="less">
    .dropNav {
        .ant-drawer-header {
            border: none;
            padding: 0;
            height: 0;
        }

        .ant-drawer-content-wrapper {
            height: auto !important;
        }

        &_list {
            display: flex;
            flex-wrap: wrap;
            box-sizing: border-box;
            padding: 15px;
            justify-content: flex-start;
            position: relative;

            &:after {
                display: block;
                content: "";
                position: absolute;
                left: 15px;
                height: calc(100% - 30px);
                top: 15px;
                background: #fff;
                width: 1px;
            }

            &:before {
                display: block;
                content: "";
                position: absolute;
                left: 15px;
                width: calc(100% - 30px);
                bottom: 15px;
                background: #fff;
                height: 1px;
            }

            &_name {
                font-size: 20px;
                color: rgba(0, 0, 0, 0.85);
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
            }

            &_single {
                width: 440px;
                box-sizing: border-box;
                padding: 30px 80px;
                border-bottom: 1px solid rgba(0, 0, 0, 0.06);
                border-left: 1px solid rgba(0, 0, 0, 0.06);
            }
        }

        &_childrenList {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;

            &_single {
                margin: 8px 24px 0 0;
                font-size: 14px;
                color: rgba(0, 0, 0, 0.65);

                &:hover {
                    color: #5cadff;
                }
            }

            &_link {
                color: rgba(0, 0, 0, 0.65);
            }
        }
    }
</style>