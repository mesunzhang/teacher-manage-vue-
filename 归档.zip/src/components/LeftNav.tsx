import { Component, Vue } from 'vue-property-decorator'
import { RawLocation } from 'vue-router/types/router'
import { CreateElement } from 'vue'
import { getLeftNavList } from '@/httpService/global.service'

Component.registerHooks([
  'beforeRouteEnter'
])

@Component({
  components: {},
  // name:"NavLayout"
})
export default class NavLayout extends Vue {
  collapsed: boolean = false
  selectKey: any[] = []
  openKey: any[] = []
  navList: any[] = []

  async getList() {
    this.navList = await getLeftNavList({
      finally: () => {
      }
    })
    this.openKey = [this.navList[this.navList.findIndex((value) => {
      return JSON.stringify(value).indexOf(this.selectKey[0]) >-1
    })]['name']]
  }

  created() {
    this.selectKey = [this.$route.name]
    this.getList()
  }

  linkTo(route: string) {
    this.$router.push({ name: route })
  }

  renderMenu(h: CreateElement, list: any) {
    return list.map((item: any) => {
      if (item.children && item.children.length) {
        return (
          <a-sub-menu key={item.name}>
            <span slot="title">
              <a-icon type={item.meta.icon || 'menu'} />
              {item.meta ? item.meta.title : item.name}
            </span>
            {this.renderMenu(h, item.children)}
          </a-sub-menu>
        )
      } else {
        return (
          <a-menu-item key={item.name} class={item.path} onClick={() => this.linkTo(item.name)}>
            {item.meta ? item.meta.title : item.name}
          </a-menu-item>
        )
      }
    })
  }

  render(h: CreateElement) {
    return (
      <a-menu
        mode="inline"
        theme="dark"
        vModel={this.selectKey}
        on={{ ['update:openKeys']: this.openKeysChange }}
        open-keys={this.openKey}
        style={{ height: '100%', borderRight: 0 }}
      >
        {this.renderMenu(h, this.navList)}
      </a-menu>
    )
  }

  openKeysChange(openkey: any) {
    this.openKey = openkey
  }
}
