<template>
	<div>
		<a-modal
			title="共享"
			:visible="visible"
			width="605px"
			@cancel="handleCancel"
			@ok="handleOk"
		>
		</a-modal>
	</div>
</template>

<script>
export default {
	props: {
		visible: {
			type: Boolean,
			default: false
		}
	},
	model: {
		prop: "visible"
	},
	data() {
		return {};
	},
	mounted() {},
	methods: {
		handleCancel() {
			this.visible = false;
			this.$emit("change", false);
		},
		handleOk() {
			this.handleCancel();
		}
	}
};
</script>

<style lang="less"></style>
