<template>
	<div>
		<a-modal title="移动到" :visible="visible" width="605px"> </a-modal>
	</div>
</template>

<script>
export default {
	props: {
		visible: {
			type: Boolean,
			default: false
		}
	},
	model: {
		prop: "visible"
	},
	data() {
		return {
			visible: true
		};
	},
	mounted() {},
	methods: {
		handleCancel() {
			this.visible = false;
			this.$emit("change", false);
		},
		handleOk() {
			this.handleCancel();
		}
	}
};
</script>

<style lang="less"></style>
