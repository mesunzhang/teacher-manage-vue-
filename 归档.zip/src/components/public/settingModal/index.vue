<template>
	<div>
		<a-modal
			:title="this.title"
			:visible="visible"
			:confirm-loading="confirmLoading"
			@cancel="handleCancel"
			width="720px"
			v-if="renderObj"
		>
			<div class="content">
				<div
					v-for="(parentItem, index) in renderObj.renderList"
					:key="index"
					class="item"
				>
					<div class="title">
						<h4>{{ parentItem.title }}</h4>
						<span style="padding-left: 10px; color: #3f3f3f">{{
							parentItem.subTitle
						}}</span>
					</div>
					<div v-if="parentItem.checkBox">
						<a-checkbox
							:indeterminate="indeterminate"
							:checked="checkAll"
							@change="onCheckAllChange"
						>
							全选
						</a-checkbox>
						<a-checkbox-group
							v-model="parentItem.value"
							:options="parentItem.radioList"
							@change="onCheckoutChange"
						/>
					</div>
					<a-radio-group
						v-model="parentItem.value"
						@change="onChange"
						v-else
					>
						<a-radio
							v-for="item in parentItem.radioList"
							:key="item.label"
							:value="item.value"
						>
							{{ item.label }}
						</a-radio>
						<a-radio
							:value="
								parentItem.type == 'openTime'
									? openTime
									: closingTime
							"
							v-if="
								(parentItem.type == 'openTime'
									? openTime
									: closingTime) && parentItem.showTimer
							"
						>
							{{
								parentItem.type == "openTime"
									? openTime
									: closingTime
							}}
						</a-radio>
					</a-radio-group>
					<a-date-picker
						v-if="parentItem.showTimer"
						placeholder="自定义时间"
						format="YYYY-MM-DD HH:mm"
						@change="
							changeTime($event, parentItem.type, parentItem)
						"
						:disabled-date="disabledDate"
						:show-time="{}"
					>
						<span class="link">{{ "请选择" }}</span>
					</a-date-picker>
				</div>
			</div>
			<template slot="footer">
				<a-button
					key="submit"
					type="primary"
					:loading="confirmLoading"
					@click="handleOk"
				>
					确定
				</a-button>
			</template>
		</a-modal>
		<a-modal
			title="选择日期"
			:visible="calendarVisible"
			@cancel="handleCalendarCancel"
			:footer="null"
			:width="350"
		>
			<div>
				<!-- <a-calendar :fullscreen="false" @panelChange="onPanelChange" /> -->
				<!-- <a-date-picker
					placeholder="自定义时间"
					format="YYYY-MM-DD HH:mm"
					@change="changeTime($event, 'open')"
					:disabled-date="disabledDate"
					:show-time="{}"
				>
				
				</a-date-picker> -->
			</div>
		</a-modal>
	</div>
</template>
<script>
import moment from "moment";
// setAuth
export default {
	model: {
		prop: "visible"
	},
	props: {
		type: {
			default: "open",
			type: String
		},
		visible: {
			default: true,
			type: Boolean
		},
		openClassList: {
			default: [],
			type: Array
		},
		selectedTabsValue: {
			default: ""
		}
	},
	data() {
		return {
			lastType: "empty",
			closingTime: "",
			openTime: "",
			calendarVisible: false,
			confirmLoading: false,
			renderObj: null,
			indeterminate: false,
			checkAll: false,
			openRenderObj: {
				title: "公开设置",
				subTitle: "所选文件开放给哪些学生？什么时间浏览？",
				renderList: [
					{
						title: "公开对象",
						subTitle: "",
						value: [],
						checkBox: true,
						radioList: this.openClassList
					},
					{
						title: "开放时间",
						subTitle: "（指定某天为指定日期的早上0点）",
						value: 1,
						showTimer: true,
						type: "openTime",
						radioList: [
							{ value: 1, label: "现在" },
							{ value: 2, label: "明天" },
							{ value: 3, label: "后天" }
						]
					},
					{
						title: "关闭时间",
						subTitle:
							"（指定某天为指定日期的晚上24点，默认为长期开放）",
						value: 1,
						type: "closingTime",
						showTimer: true,
						radioList: [
							{ value: 1, label: "无" },
							{ value: 2, label: "明天" },
							{ value: 3, label: "后天" },
							{ value: 4, label: "本周日" }
						]
					}
				]
			},
			closeRenderObj: {
				title: "关闭设置",
				subTitle: "所选文件暂停让学生浏览",
				renderList: [
					{
						title: "关闭对象",
						subTitle: "",
						checkBox: true,
						value: [],
						radioList: this.openClassList
					}
					// {
					// 	title: "关闭时间",
					// 	value: "",
					// 	subTitle:
					// 		"（指定某天为指定日期的晚上24点，默认为长期开放）",
					// 	radioList: [
					// 		{ value: 1, label: "无" },
					// 		{ value: 2, label: "明天" },
					// 		{ value: 3, label: "后天" },
					// 		{ value: 4, label: "本周日" },
					// 		{ value: 505, label: "自定义" }
					// 	]
					// }
				]
			}
		};
	},
	created() {},
	watch: {
		type(type) {
			this.lastType = type;
			this.init(type);
		},
		// 初始化
		visible(newval) {
			// debugger
			this.init(this.type);
		}
	},
	methods: {
		clearData() {
			this.visible = true;
		},
		init(type) {
			this.renderObj =
				type === "open" ? this.openRenderObj : this.closeRenderObj;
			// 去除全部选项
			let handledArray = this.openClassList.slice(1);
			this.renderObj.renderList[0].radioList = handledArray;
			if (this.selectedTabsValue != " ") {
				this.renderObj.renderList[0].value = [this.selectedTabsValue];
				this.checkAll = false;
				this.indeterminate = true;
			} else {
				this.checkAll = true;
				this.indeterminate = false;
				this.renderObj.renderList[0].value = handledArray.map(
					item => item.value
				);
			}
			// 开放时间 选中的值->初始化
			if (this.renderObj.renderList[1]) {
				this.renderObj.renderList[1].value = 1;
				// 清空自定义时间
				this.openTime = "";
			}
			//关闭时间
			if (this.renderObj.renderList[2]) {
				this.renderObj.renderList[2].value = 1;
				this.closingTime = "";
			}
		},
		// 公开对象 || 关闭对象 复选框 -> 点击成员选项
		onCheckoutChange(checkedList) {
			this.indeterminate =
				!!checkedList.length &&
				checkedList.length <
					this.renderObj.renderList[0].radioList.length;
			this.checkAll =
				checkedList.length ===
				this.renderObj.renderList[0].radioList.length;
		},
		// 公开对象 || 关闭对象 复选框 -> 点击全选
		onCheckAllChange(e) {
			this.renderObj.renderList[0].value = e.target.checked
				? this.renderObj.renderList[0].radioList.map(item => item.value)
				: [];
			Object.assign(this, {
				indeterminate: false,
				checkAll: e.target.checked
			});
		},
		disabledDate(current) {
			// Can not select days before today and today
			return current && current < moment();
		},
		changeTime(time, type, item) {
			time = time.format("YYYY-MM-DD HH:mm");
			this[type] = time;
			item.value = time;
			// console.log(time, type);
		},
		title(h) {
			const spanNode = h(
				"span",
				{
					style: {
						color: "#999",
						fontSize: "12px",
						paddingLeft: "10px"
					}
				},
				this.renderObj.subTitle
			);
			return h("div", { style: { color: "#333" } }, [
				h(
					"span",
					{ style: { fontSize: "16px" } },
					this.renderObj.title
				),
				spanNode
			]);
		},

		onChange(e) {},
		handleOk(e) {
			let valueList = this.renderObj.renderList.map(item => item.value);
			let flag = valueList.every(item => item);
			//已废弃
			// if (!flag) {
			// 	// 关闭设置
			// 	if (this.type == "close") {
			// 		return this.$message.error("请选择");
			// 		// 公开设置
			// 	} else {
			// 		if (!this.closingTime && !this.openTime) {
			// 			return this.$message.error("请选择");
			// 		}
			// 	}
			// }
			if (!flag) {
				return this.$message.error("请选择");
			}
			// debugger;
			let publicObject = [];
			//公开对象 -> 将value 转换为参数
			valueList[0].forEach(value => {
				publicObject.push(
					[
						this.openClassList.find(item => {
							return item.value == value;
						})
					].map(item => {
						return {
							classId: item.value,
							className: item.label,
							classType: item.classType
						};
					})
				);
			});
			//扁平化
			publicObject = publicObject.flat(Infinity);
			// 公开权限操作
			if (this.type == "open") {
				//valueList[0] 公开对象
				//valueList[1] 开放时间
				//valueList[2] 关闭时间

				let data = {
					openTime: valueList[1],
					closingTime: valueList[2],
					publicObject,
					type: this.type
				};
				this.$emit("change", data);
				// 关闭权限操作
			} else {
				//valueList[0] 关闭对象
				//valueList[1] 关闭时间
				let classInfo = publicObject;
				let data = {
					classInfo,
					type: this.type
				};
				this.$emit("change", data);
			}
			this.confirmLoading = true;
			setTimeout(() => {
				this.confirmLoading = false;
			}, 1000);
		},
		handleCancel(e) {
			this.$emit("change", false);
		},

		showCalendar() {
			this.calendarVisible = true;
		},
		handleCalendarCancel() {
			this.calendarVisible = false;
		},
		onPanelChange(params) {
			console.log(params);
		}
	}
};
</script>
<style scoped lang="less">
.link {
	cursor: pointer;
	color: #2274c3;
}
.content {
	font-size: 14px;
	.item {
		margin-bottom: 20px;
		.title {
			display: flex;
		}
	}
}
</style>
