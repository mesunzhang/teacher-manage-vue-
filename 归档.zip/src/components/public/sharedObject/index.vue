<template>
	<div>
		<a-modal
			title="共享库设置"
			width="605px"
			:visible="visible"
			@cancel="handleCancel"
			@ok="handleOk"
		>
			<div class="shareObject">
				<div class="subjectBox">
					<div>选择科目：</div>
					<a-select
						style="width: 120px"
						@change="handleProvinceChange"
						v-model="subjectId"
					>
						<a-select-option
							v-for="subject in subjectList"
							:key="subject.id"
						>
							{{ subject.name }}
						</a-select-option>
					</a-select>
				</div>
				<div class="publicBox">
					<div class="title">权限设置：</div>
					<div class="content">
						打开开关，对应的班级即可查看对应共享库
					</div>
				</div>
				<div class="table">
					<div class="author">
						<div class="title">班级</div>
						<div
							class="cell"
							v-for="item in roleList"
							:key="item.id"
						>
							{{ item.name }}
						</div>
					</div>
					<div class="power">
						<div class="title">共享库权限</div>
						<div class="cellBox">
							<!-- detail = { } id == key item == value -->
							<div
								class="cell"
								v-for="(item, id) in detail"
								:key="id"
							>
								<a-checkbox-group>
									<a-checkbox
										v-for="member in pageShowDetail[id]"
										:key="member.id"
										:value="member.id"
										@change="changeCheckbox"
									>
										{{ member.name }}
									</a-checkbox>
								</a-checkbox-group>
							</div>
						</div>
					</div>
				</div>
			</div>
		</a-modal>
	</div>
</template>

<script>
import PowerApi from "@/api/powerControl";
export default {
	props: {
		visible: {
			type: Boolean,
			default: false
		}
	},
	model: {
		prop: "visible"
	},
	data() {
		return {
			classList: ["全部班级", "701班", "702班", "703班"],
			subjectId: "", //活跃id
			subjectList: [],
			roleList: [], //角色列表
			grades: [], //年级列表
			detail: [], //年级复选框选项列表
			pageShowDetail: {}
		};
	},
	mounted() {
		console.log(this.visible);
		this.getConfig();
	},
	methods: {
		handleCancel() {
			this.visible = false;
			this.$emit("change", false);
		},
		handleOk() {
			this.handleCancel();
		},
		handleProvinceChange() {},
		changeCheckbox() {},
		// 获取教师学科
		getBaseConfig() {
			let promise = new Promise((resolve, reject) => {
				PowerApi.getBaseConfig({ name: "subject" }).then(res => {
					res = res.subject;
					this.subjectId = res[0].id;
					this.subjectList = res;
					resolve();
				});
			});
			return promise;
		},
		// 获取共享库设置
		getConfig() {
			let wait = this.getBaseConfig();
			wait.then(() => {
				PowerApi.getConfig({ subject: this.subjectId - 0 }).then(
					res => {
						res.class.unshift({ name: "全部", id: 0 });
						this.roleList = res.class;
						this.grades = res.grades;
						let detail = res.detail;
						// 添加全部选项
						// this.grades.unshift({ id: 0, name: "全部" });
						// detail[0] = [];
						this.detail = detail;
						// 页面展示( 复选框选项 )需要的数据结构
						/** key为班级id
						 * {
						 *  3:["七年级，七年级"],
						 *  4:["七年级，七年级"],
						 * }
						 */

						for (let key in detail) {
							// 拿到班级id对应的name
							let object = this.grades.find(grade => {
								return key == grade.id;
							});
							let name = object.name;

							// 渲染出复选项列表需要的name数组
							let nameArray = this.roleList.map(_ => {
								return { name, id: _.id };
							});

							this.pageShowDetail[key] = nameArray;
							this.pageShowDetail[`proxy${key}`] = [];
							console.log(this.pageShowDetail);
						}
						console.log(res);
					}
				);
			});
		}
	}
};
</script>

<style lang="less">
.shareObject {
	.subjectBox {
		width: 100%;
		display: flex;
		align-items: center;
		height: 40px;
		color: #333333;
	}
	.publicBox {
		width: 100%;
		height: 40px;
		display: flex;
		align-items: center;
		.title {
			font-family: PingFangSC-Regular;
			font-size: 14px;
			color: #333333;
			letter-spacing: 0;
			text-align: justify;
			line-height: 14px;
		}
		.content {
			font-family: PingFangSC-Regular;
			font-size: 12px;
			color: #999999;
			letter-spacing: 0;
			line-height: 16px;
		}
	}
	.table {
		height: 350px;
		background: #ffffff;
		border: 1px solid #e5e5e5;
		border-radius: 2px;
		margin-top: 16px;
		display: flex;
		.author {
			width: 180px;
			height: 100%;
			border-right: 1px solid #e5e5e5;
			.cell {
				padding: 12px 20px;
				font-family: PingFangSC-Regular;
				font-size: 14px;
				color: #333333;
				letter-spacing: 0;
				line-height: 14px;
				height: 38px;
				&:nth-child(2) {
					padding: 20px;
					height: 54px;
				}
				&:nth-child(2n-1) {
					background: rgba(0, 0, 0, 0.04);
				}
			}
		}
		.power {
			flex: 1;
			.cellBox {
				display: flex;
			}
			.ant-checkbox-wrapper {
				height: 38px;
				width: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				margin: 0;
				padding: 12px 20px;
				&:nth-child(1) {
					padding: 20px;
					height: 54px;
				}
				&:nth-child(2n) {
					background: rgba(0, 0, 0, 0.04);
				}
			}
			.cell {
				flex: 1;
				display: flex;
				flex-direction: column;
				font-family: PingFangSC-Regular;
				font-size: 14px;
				color: #333333;
				letter-spacing: 0;
			}
		}
		.title {
			padding: 20px;
			font-family: PingFangSC-Regular;
			font-size: 14px;
			color: #333333;
			letter-spacing: 0;
			line-height: 14px;
			border-bottom: 1px solid #eee;
		}
	}
}
</style>
