<template>
    <a-modal
            :visible="visible"
            dialogClass="relationModel"
            :destroyOnClose="true"
            :footer="null"
            :maskClosable="false"
            :closable="false"
            :centered="true"
    >
        <div class="box" flex>
            <div class="left">
                <a-input class="search" placeholder="input search text" style="width: 376px;height: 40px;"
                         @search="onSearch">
                    <a-icon type="search" slot="prefix"/>
                </a-input>
                <!--                    表格-->
                <a-table size="small" rowKey="id"
                         :columns="columns" :data-source="data"
                         :pagination="false">
                    <a-checkbox slot="checkTitle" :indeterminate="allSelectCount>0&&allSelectCount<data.length"
                                :checked="allSelectCount===data.length"
                                @change="allSelectCount=$event.target.checked"></a-checkbox>
                    <a-checkbox slot="check" slot-scope="record" v-model="record.check"></a-checkbox>
                </a-table>
            </div>
            <div class="right">
                <div class="right-header" flex="main:justify cross:center">
                    <span>已关联{{relationData.length}}</span>
                    <div><i class="iconshanchu iconfont "></i><a>清空</a></div>
                </div>
                <div class="relation-table">
                    <div class="relation-table-row" v-for="(item, index) of relationData" :key="index"
                         flex="main:justify cross:center">
                        <span>1</span>
                        <span>名字</span>
                        <span>{{item.name}}</span>
                        <span>男</span>
                        <span><i class="iconguanbi iconfont"></i></span>
                    </div>
                </div>
                <div class="foot">
                    <a-button @click="handleCancel">取消</a-button>
                    <a-button type="primary" @click="handleOk" :loading="confirmLoading">保存</a-button>
                </div>
            </div>

        </div>
    </a-modal>
</template>
<script lang="ts">
  import { Component, Vue } from 'vue-property-decorator'

  const data: any = []
  for (let i = 0; i < 9; i++) {
    data.push({
      id: i,
      name: `云作业 ${i}`,
      obj: 'sdsd',
      check: false
    })
  }

  @Component({
    components: {}
  })
  export default class RelationModel extends Vue {
    visible: boolean = false
    confirmLoading: boolean = false
    resolve?: Function
    columns: any[] = [
      {
        align: 'center',
        title: '#',
        dataIndex: 'id'
      },
      {
        width: 120,
        title: '应用名',
        dataIndex: 'name'
      },
      {
        title: '面向对象',
        dataIndex: 'obj'
      },
      {
        width: 40,
        key: 'check',
        slots: { title: 'checkTitle' },
        scopedSlots: { customRender: 'check' }
      }
    ]
    data: any = data
    relationData: any = [
      {
        name: '是啊啊'
      },
      {
        name: '是啊'
      }
    ]

    show(resolve: Function, type: number) {
      this.resolve = resolve
      this.visible = true
    }

    handleOk() {
      this.confirmLoading = true
      this.resolve && this.resolve(
        'value',
        (status: boolean) => {
          this.confirmLoading = false
          if (status) {
            this.visible = false
          }
        }
      )
    }

    handleCancel() {
      this.resolve = undefined
      this.confirmLoading = false
      this.visible = false
    }

    onSearch() {

    }

    get allSelectCount() {
      return this.data.filter((i: any) => i.check).length
    }

    set allSelectCount(value: boolean) {
      this.data.forEach((i: any) => {
        i.check = value
      })
    }
  }
</script>
<style scoped lang="less">
    .box {
        align-items: stretch;
        height: 100%;
        border-radius: 4px;
        flex-wrap: wrap;

        .left, .right {
            padding-bottom: 61px !important;
        }

        .left {
            padding: 32px;
            width: 440px;
            text-align: center;

            .search {
                margin-bottom: 16px;
            }
        }

        .right {
            position: relative;
            padding: 32px;
            flex: 1;
            z-index: 10;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.16);
            font-size: 12px;
            color: rgba(0, 0, 0, 0.65);

            &-header {
                margin-top: 11px;
                font-size: 12px;
                color: rgba(0, 0, 0, 0.65);
                font-weight: bold;

                i, a {
                    vertical-align: text-top;
                    font-weight: 400;
                }

                i {
                    color: #2d8cf0;
                    font-size: 14px;
                    margin-right: 5px;
                }
            }

            .relation-table {
                margin-top: 16px;
                border: 1px solid rgba(0, 0, 0, 0.06);
                font-size: 14px;
                color: rgba(0, 0, 0, 0.45);
                text-align: left;

                &-row {
                    height: 40px;
                    border-bottom: 1px solid rgba(0, 0, 0, 0.06);

                    &:hover {
                        background-color: #F0F7FF;

                        i {
                            display: inline-block;
                        }
                    }

                    span:nth-of-type(1) {
                        width: 60px;
                        text-align: center;

                    }
                    span:nth-of-type(2),span:nth-of-type(3){
                        flex:1
                    }

                    span:last-of-type {
                        display: inline-block;
                        width: 60px;
                        text-align: right;
                        padding-right: 18px;
                    }

                    i {
                        display: none;
                        font-size: 12px;
                    }
                }

                &-row:last-of-type {
                    border-bottom: none;
                }
            }

            .foot {
                height: 32px;
                position: absolute;
                bottom: 61-32px;
                right: 32px;

                button {
                    margin-left: 8px;
                }
            }
        }

    }

</style>

<style lang="less">
    .relationModel {
        width: 880px !important;
        /*max-height: 560px !important;*/
        /*min-height: 387px!important;*/
        overflow: hidden;
        .ant-table-thead{
            background: rgba(0,0,0,0.06);
            .ant-table-header-column{
                font-weight: bold;
                font-size: 12px;
                color: rgba(0,0,0,0.65);
            }
        }

        .ant-table-body {
            margin: 0 !important;
            td{
                font-size: 12px;
                color: rgba(0,0,0,0.65);
            }
        }

        .ant-modal-content {
            height: 100%;
            display: flex;
            flex-direction: column;

            .ant-modal-body {
                flex: 1;
                padding: 0;
            }
        }
    }
</style>