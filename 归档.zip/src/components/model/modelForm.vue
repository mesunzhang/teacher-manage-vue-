<template>
    <a-modal v-model="visible" :title="header"
             @ok="handleOk" @cancel="handleCancel"
             :confirm-loading="confirmLoading"
             :okText="config.confirmText||'确定'"
             :cancelText="config.cancelText||'取消'"
             v-bind="model">
        <FormConfig ref="collectionForm" :config="{...config, confirmShow: false,cancelShow: false}"
                    :options="options"></FormConfig>
        <template slot="footer">
            <slot name="footer" :handle="{handleOk,handleCancel}" :loading="confirmLoading" :custom="custom">
            </slot>
        </template>
    </a-modal>
</template>
<script lang="ts">
  import { Component, Vue, Prop, Ref } from 'vue-property-decorator'
  import FormConfig from '../form/formFactory'

  const PropVue = Vue.extend({
    props: {
      config: {
        type: Object,
        default() {
          return {}
        }
      },
      model: {
        type: Object,
        default() {
          return {}
        }
      }
    }
  })
  @Component({
    components: { FormConfig }
  })
  export default class ModelForm extends PropVue {
    @Prop() options: any
    @Ref() collectionForm: any
    @Prop() header?: string
    resolve?: Function
    visible: boolean = false
    confirmLoading: boolean = false
    custom: any = '' // 按钮的名字  自定义按钮时候可能需要

    async handleOk(custom: any) {
      this.custom = custom;
      const form = this.collectionForm.form
      try {
        const res = await form.validateFields()
        this.confirmLoading = true
        this.resolve && this.resolve(res, (status: boolean = true) => {
          this.confirmLoading = false
          if (status) {
            this.visible = false
            form.resetFields()
          }
        }, custom)
      } catch (e) {
      }
    }

    handleCancel() {
      this.resolve = undefined
      const form = this.collectionForm.form
      form.resetFields()
      this.confirmLoading = false
      this.visible = false
    }

    public show(resolve: Function, init: any) {
      this.resolve = resolve
      this.visible = true
      this.$nextTick(() => {
        if (init) {
          this.collectionForm.setFormValue(init)
        }
      })
    }
  }
</script>

<style scoped lang="less">

</style>