<template>
	<div class="upload-content">
		<div class="left-title">学科:</div>
		<a-select style="width: 200px" v-model="subjectId">
			<a-select-option v-for="item of subjectList" :key="item.id">{{
				item.name
			}}</a-select-option>
		</a-select>
		<div class="upload-desc" @click="showDesc = !showDesc">
			文件上传说明
			<a-icon type="down" v-show="!showDesc" />
			<a-icon type="up" v-show="showDesc" />
		</div>
		<div class="detail">
			<div class="desc" v-show="showDesc" v-html="explainHtml"></div>
			<a-upload-dragger
				name="file"
				:before-upload="beforeUpload"
				:data="{ subjectId, parentId }"
				:multiple="true"
				:showUploadList="false"
				action="/resource/Resource/uploadSourceFile"
				@change="handleChange"
			>
				<div class="upload-box">
					<a-icon type="upload" />
					点击或把文件直接拖至此区域
				</div>
			</a-upload-dragger>
			<div class="upload-file" v-show="fileList.length">
				<p>上传中（{{ completeCount }}/{{ fileList.length }}）</p>
				<div class="file-item" v-for="file in fileList" :key="file.uid">
					<img
						v-show="'png,jpg,jpeg,gif'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_img.png"
					/>
					<img
						v-show="'mp3,wav,amr'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_yinpin.png"
					/>
					<img
						v-show="'cwp,cwep'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_weike.png"
					/>
					<img
						v-show="'ppt,pptx'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_ppt.png"
					/>
					<img
						v-show="'doc,docx'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_word.png"
					/>
					<img
						v-show="'mp4,flv'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_video.png"
					/>
					<img
						v-show="'pdf'.indexOf(file.type) >= 0"
						src="../../assets/img/icon/ic_pdf.png"
					/>
					<span class="file-name" :title="file.name">{{
						file.name
					}}</span>
					<span class="file-size">{{ file.size }}</span>
					<span class="file-status">
						<span v-show="file.status === 'uploading'"
							>上传中<a-icon type="loading"
						/></span>
						<span v-show="file.status === 'done'"
							><img
								style="width: 16px; height: 16px; margin: 0"
								src="../../assets/img/icon/ic_file_success.png"
						/></span>
						<span v-show="file.status === 'error'">上传失败</span>
					</span>
				</div>
			</div>
		</div>
		<div class="left-title">权限设置：</div>
		<a-radio-group v-model="authValue">
			<a-radio :value="1"> 不公开 </a-radio>
			<a-radio :value="2"> 公开 </a-radio>
		</a-radio-group>
		<div class="auth-detail" v-show="authValue === 2">
			<p>公开对象</p>
			<a-checkbox
				:indeterminate="indeterminate"
				:checked="checkAll"
				@change="onCheckAllChange"
			>
				全选
			</a-checkbox>
			<a-checkbox-group
				v-model="checkedList"
				:options="classList"
				@change="onChange"
			/>
			<p class="time-title">
				开放时间<span class="desc"
					>（指定某天为指定日期的早上0点）</span
				>
			</p>
			<a-radio-group v-model="openTime">
				<a-radio :value="1"> 现在 </a-radio>
				<a-radio :value="2"> 明天 </a-radio>
				<a-radio :value="3"> 后天 </a-radio>
				<a-radio :value="openRadioTime" v-if="openRadioTime">
					{{ openRadioTime }}
				</a-radio>
			</a-radio-group>
			<a-date-picker
				placeholder="自定义时间"
				format="YYYY-MM-DD HH:mm"
				:disabled-date="disabledDate"
				@change="changeTime($event, 'open')"
				:show-time="{}"
			>
				<span class="link">{{ "请选择" }}</span>
			</a-date-picker>
			<p class="time-title">
				关闭时间<span class="desc"
					>（指定某天为指定日期的晚上24点，默认为长期开放）</span
				>
			</p>
			<a-radio-group v-model="closingTime">
				<a-radio :value="1"> 无 </a-radio>
				<a-radio :value="2"> 明天 </a-radio>
				<a-radio :value="3"> 后天 </a-radio>
				<a-radio :value="4"> 本周日 </a-radio>
				<a-radio :value="closingRadioTime" v-if="closingRadioTime">
					{{ closingRadioTime }}
				</a-radio>
			</a-radio-group>
			<a-date-picker
				placeholder="自定义时间"
				format="YYYY-MM-DD HH:mm"
				:disabled-date="disabledDate"
				@change="changeTime($event, 'closing')"
				:show-time="{}"
				><span class="link">{{ "请选择" }}</span>
			</a-date-picker>
		</div>
		<div class="bottom-button">
			<a-button
				type="primary"
				@click="confirm"
				:loading="fileList.length !== completeCount"
				>确定</a-button
			>
		</div>
	</div>
</template>

<script>
import commonApi from "@/api/commonApi";
import moment from "moment";
export default {
	data() {
		return {
			//   subjectId: "",
			//   parentId: "",
			//   subjectList: [],
			checkedList: [],
			showDesc: false,
			authValue: 1,
			fileList: [],
			completeCount: 0,
			classList: [],
			// 半选择状态
			indeterminate: false,
			checkAll: false,
			openTime: 1,
			openRadioTime: "",
			closingTime: 1,
			closingRadioTime: "",
			explainHtml: "",
			uploadAllowedTypes: "",
			uploadFileSize: 0
		};
	},
	props: {
		subjectId: {
			type: String,
			default: ""
		},
		parentId: {
			type: String,
			default: ""
		},
		subjectList: {
			type: Array,
			default() {
				return [];
			}
		}
	},
	mounted() {
		console.log(this.subjectId);
		if (window.top && window.top.$ && window.top.$.tools) {
			let $ = window.top.$;
			this.subjectList = $.tools.getCommonSession({
				name: "commonList",
				getCommon: $.tools.getList
			}).subject;
		}
		if (this.$route.query.defaultSubject) {
			this.subjectId = parseInt(this.$route.query.defaultSubject);
		}
		commonApi.getClassList().then(res => {
			this.classList = res.data.map(item => {
				return {
					label: item.className,
					value: item.classId,
					classType: item.classType,
					className: item.className
				};
			});
		});
		// 获取格式列表
		commonApi.getUploadExplain().then(res => {
			// 上传说明
			this.explainHtml = res.data.uploadExplain;
			//   允许格式
			this.uploadAllowedTypes = res.data.uploadAllowedTypes;
			//   文件大小限制
			this.uploadFileSize = parseInt(res.data.uploadFileSize);
		});
	},
	methods: {
		disabledDate(current) {
			// Can not select days before today and today
			return current && current < moment();
		},
		beforeUpload(file) {
			const fileType = file.name.split(".").pop();
			const isAllowType =
				this.uploadAllowedTypes.indexOf(fileType.toUpperCase()) >= 0;
			if (!isAllowType) {
				this.$message.error("选择的文件中包含不支持的格式!");
			}
			const isLt2M = file.size / 1024 / 1024 < this.uploadFileSize;
			if (!isLt2M) {
				this.$message.error("请注意上传文件大小限制！");
			}
			return isAllowType && isLt2M;
		},
		handleChange(info) {
			this.fileList = info.fileList.filter(item => item.status);
			this.completeCount = info.fileList.filter(
				item =>
					(item.response && item.response.code === 200) ||
					item.status === "error"
			).length;
			this.fileList.map(file => {
				if (typeof file.size === "number") {
					if (file.size / 1024 / 1024 > 1) {
						file.size = (file.size / 1024 / 1024).toFixed(2) + "M";
					} else {
						file.size = (file.size / 1024).toFixed(2) + "kb";
					}
				}
				file.type = file.name
					.split(".")
					[file.name.split(".").length - 1].toLowerCase();
			});
			console.log(this.fileList);
		},
		onChange(checkedList) {
			this.indeterminate =
				!!checkedList.length &&
				checkedList.length < this.classList.length;
			this.checkAll = checkedList.length === this.classList.length;
			console.log(this.checkedList);
		},
		onCheckAllChange(e) {
			Object.assign(this, {
				checkedList: e.target.checked
					? this.classList.map(item => item.value)
					: [],
				indeterminate: false,
				checkAll: e.target.checked
			});
		},
		changeTime(time, type) {
			this[type + "Time"] = time.format("YYYY-MM-DD HH:mm");
			this[type + "RadioTime"] = time.format("YYYY-MM-DD HH:mm");
			console.log(time);
		},
		init(){
			this.fileList = [];
			this.completeCount = 0;
		},
		// 提交逻辑
		confirm() {
			// 获取已上传文件列表
			let resourceList = this.fileList.map(file => {
				if (file.response && file.response.code === 200) {
					return {
						isdir: 1,
						resourceId: file.response.resourceId
					};
				}
			});
			resourceList = resourceList.filter(item => item);
			//   公开后的设置
			if (this.authValue === 2 && resourceList.length) {
				const publicObject = this.checkedList.map(item => {
					console.log(this.classList);
					const classObj = this.classList.find(
						classItem => classItem.value === item
					);
					return {
						classId: item,
						className: classObj.className,
						classType: classObj.classType
					};
				});
				// 权限设置
				commonApi
					.setAuth({
						resourceList,
						openTime: this.openTime,
						closingTime: this.closingTime,
						publicObject
					})
					.then(res => {
						if (res.code === 200) {
							this.init();
							this.$emit("getFilesList");
						}
					});
			} else {
				this.init();
				this.$emit("getFilesList");
			}
		}
	}
};
</script>

<style lang="less" scoped>
.upload-content {
	padding: 20px;
	background: white;
	height: auto;
	overflow: auto;
	.left-title {
		display: inline-block;
		width: 70px;
	}
	.upload-desc {
		margin-top: 6px;
		float: right;
		color: #666666;
		cursor: pointer;
		&:hover {
			color: #2274c3;
		}
	}
	.detail {
		margin-top: 10px;
		margin-left: 70px;
		margin-bottom: 20px;
		.desc {
			padding: 10px;
			margin-bottom: 10px;
			border: 1px dashed #ccc;
			p {
				margin-bottom: 10px;
			}
		}
		.upload-box {
			line-height: 80px;
			text-align: center;
			&:hover {
				color: #2274c3;
			}
		}
		.upload-file {
			margin-top: 10px;
			background: #f8f8f8;
			overflow: hidden;
			padding-bottom: 8px;
			p {
				color: #333;
				padding: 10px;
				margin-bottom: 0;
			}
			.file-item {
				padding: 0 10px;
				width: 50%;
				line-height: 32px;
				height: 32px;
				display: flex;
				float: left;
				img {
					width: 16px;
					height: 16px;
					margin-top: 9px;
					margin-right: 5px;
				}
				i {
					line-height: 32px;
					margin-left: 5px;
					&.anticon-loading {
						color: #2274c3;
					}
				}
				span {
					display: inline-block;
				}
				.file-name {
					width: 168px;
					vertical-align: top;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}
				.file-size {
					font-size: 12px;
					color: #666;
					margin: 0 20px;
				}
				.file-status {
					flex: 1;
					text-align: right;
				}
				&:hover {
					background: #e9edf8;
				}
			}
		}
	}
	.auth-detail {
		margin-top: 10px;
		margin-left: 70px;
		background: #f8f8f8;
		padding: 20px;
		padding-top: 12px;
		margin-bottom: 40px;
		p {
			color: #333;
			margin: 10px 0 5px 0;
			span.desc {
				color: gray;
			}
		}
		/deep/ span.ant-radio + * {
			padding-left: 4px;
		}
		/deep/ .ant-checkbox + span {
			padding-left: 4px;
		}
		.time-title {
			margin-top: 32px;
		}
		.link {
			cursor: pointer;
			color: #2274c3;
		}
	}
	.bottom-button {
		margin-top: 20px;
		text-align: right;
		position: absolute;
		width: 100%;
		right: 20px;
		bottom: 20px;
	}
}
</style>
