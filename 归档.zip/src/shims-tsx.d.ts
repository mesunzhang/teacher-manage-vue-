import Vue, { VNode } from 'vue'

declare global {
  namespace JSX {
    // tslint:disable no-empty-interface
    interface Element extends VNode {
    }

    // tslint:disable no-empty-interface
    interface ElementClass extends Vue {
    }

    interface IntrinsicElements {
      [elem: string]: any
    }
  }
}

import { ModalOptions } from 'ant-design-vue/types/modal'
import ErrorHandle from '@/util/errorHandle'


declare module 'vue/types/vue' {
  interface Vue {
    confirm: (title: string, content?: string, option?: ModalOptions) => void
    eh: ErrorHandle
    hrefTo: (url: string) => void
  }
}