export interface ErrorInfo {
  info: string
  stack?: string
  time: number
  type?: string
  router: string
  userAgent?: string
  appVersion?: string
}

const ERRORINFOLOCAL = 'ERRORINFOLOCAL'
export default class ErrorHandle {
  private infoList: ErrorInfo[] = []

  constructor() {
   this.init();
  }

  public getInfoList(){
    return this.infoList;
  }
  public saveErrorLog(error: ErrorInfo){
    this.infoList.push(error)

    if(this.infoList.length > 100){
      this.infoList = this.infoList.slice(-100)
    }
    localStorage.setItem(ERRORINFOLOCAL, JSON.stringify(this.infoList))
    this.init();
  }
  private init(){
    const local = localStorage.getItem(ERRORINFOLOCAL)
    if (local) {
      try {
        this.infoList = JSON.parse(local)
      } catch (e) {
      }
    }
  }



}