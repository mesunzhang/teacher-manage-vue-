// 获取指定名称的cookie
export function getCookie(name: string) {
  var strcookie = document.cookie//获取cookie字符串
  var arrcookie = strcookie.split('; ')//分割
  //遍历匹配
  for (var i = 0; i < arrcookie.length; i++) {
    var arr = arrcookie[i].split('=')
    if (arr[0] == name) {
      return arr[1]
    }
  }
  return ''
}


export function getBase64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = error => reject(error)
  })
}

// 将list格式化为tree
export function initTree(list : any[] ,pid : number|string ) :any[] {
    let result:any[] =[];
    let temp:any[] =[];
    for (const item of list) {
        if(item.id==pid){
            temp=initTree(item,item.id)
            if(temp.length>0){
              item.children=temp
            }
        }
        result.push(item)
    }
    return result
}


export function flatten(list: any) {
  let init: any = []
  for (let i of list) {
    const copy = {...i}
    init.push(copy)
    if (copy.children && copy.children.length) {
      copy.hasChild = true
      const children = copy.children
      delete copy.children
      init = init.concat(flatten(children))
    }
  }
  return init
}