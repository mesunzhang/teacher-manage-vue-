<template>
  <a-config-provider>
    <div id="app">
      <a-spin
        class="spin"
        :spinning="spinning"
      >
        <router-view></router-view>
      </a-spin>
    </div>
  </a-config-provider>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import { mapState } from "vuex";

@Component({
  components: {},
  computed: mapState(["spinning"]),
})
export default class App extends Vue {
  @Watch("$route")
  routerChange(to: any, from: any) {
    if (to.meta.title) {
      document.title = to.meta.title;
    }
  }

  created() {
    // this.$message.config({
    //   duration: 2,
    // });
  }
}
</script>

<style lang="less">
#app {
  font-family: PingFangSC-Medium;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  overflow-y: auto;
  overflow-x: hidden;

  & > .spin {
    height: 100%;

    .ant-spin-container {
      height: 100%;
    }
  }
}

* {
  box-sizing: border-box;
}

body {
  font-size: 24px;
  color: #333;
}

h1 {
  font-weight: 200;
}

html,
body,
div,
p,
h1 {
  border: 0;
  margin: 0;
  padding: 0;
}

strong {
  font-weight: normal;
}

em,
i {
  font-style: normal;
}

ul,
ol,
li {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.page {
  min-height: 100%;
}

.icon {
  width: 1em;
  height: 1em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}

.cursor {
  cursor: pointer;
}
</style>
