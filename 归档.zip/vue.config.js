
module.exports = {
    productionSourceMap: false,
    css: {
        sourceMap: false,
        loaderOptions: {
            less: {
                lessOptions: { javascriptEnabled: true}
            }
        }
    },
    devServer: {
        proxy: {
            '/': {
                target: 'http://school.xh.com/',
                changeOrigin: true,
                ws: true,
                onProxyReq(proxyReq) {
                    proxyReq.setHeader("Cookie", "PHPSESSID=gkg9q2a3cbgg774k5qoiceee1j; Path=/; Domain=192.168.5.5; Expires=Sat, 08 May 2021 02:04:00 GMT;Path=/; Domain=192.168.5.5; Expires=Sat, 08 May 2021 02:04:28 GMT");
                }
            }
        }
    },
}